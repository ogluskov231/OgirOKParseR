# ОгрОК_UA v0.7.1 — готовий реліз

Дата збірки сирців: 2026-10-10  
Канал: повний ребілд варіанту після Phase 1–10 (+ покращена Phase 10).

## Що це

Десктопний інструмент (Tkinter) для розбору військових наказів **DOCX → JSON → Excel** з ручним коригуванням полів, правилами категорій і автозаповненням Excel з JSON без повторного парсингу.

## Швидкий старт

```text
1. Покласти DOCX у input/documents/
2. python run_gui.py
   або RUN_GUI.bat (Windows, створить .venv)
3. Сканувати → Обробити
4. Результати: output/exports/excel/, output/parsed/combined_v2.json
```

CLI:

```text
python run_parser_orders_cli.py --input input/documents --excel --json
python run_parser_orders_cli.py --from-json output/parsed/combined_v2.json --excel
```

Перевірка релізу:

```text
python scripts/smoke_check.py
```

Windows .exe: `scripts\build_exe_windows.bat` → `dist\OgrOK_UA\OgrOK_UA.exe`  
Інсталятор: Inno Setup `installer\OgrOK_UA.iss` → `OgrOK_UA_Setup_v0.7.1.exe`

## Модульна структура (рефакторинг)

| Компонент | Шлях |
|-----------|------|
| Entrypoint | `run_gui.py` |
| Pipeline | `apps/.../services/pipeline_service.py` |
| Paths | `apps/.../services/app_paths.py` |
| Dialogs | `apps/.../gui/dialogs/` |
| Tabs | `apps/.../gui/tabs/` |
| Widgets | `apps/.../gui/widgets/` |
| Controllers | `apps/.../gui/controllers/` |
| Core | `apps/.../core/` |

## Документація в пакеті

- `README.md` — користувач
- `CHANGELOG.md` — історія
- `BUILD_WINDOWS.md` — збірка exe
- `docs/ARCHITECTURE.md`
- `docs/RELEASE_CHECKLIST_UA.md`
- `docs/PHASE1_…` … `PHASE10_RELEASE_UA.md`

## Версія

Файл `VERSION` = **0.7.1** (синхрон з ISS, README, CHANGELOG, spec).

## Залежності

Див. `requirements.txt` (python-docx, openpyxl, jsonschema, …).

## Примітки

- У пакеті немає `.venv`, `build/`, `dist/`, користувацьких наказів і `output/*` результатів.
- Для повної схеми JSON-валідації потрібен пакет `jsonschema` (тест пропускається, якщо його немає).
