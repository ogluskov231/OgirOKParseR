#!/usr/bin/env python3
"""Phase 10+ release smoke: structure, version sync, imports, unit tests (no GUI).

Exit codes:
  0 — all checks passed
  1 — tests or critical checks failed
  2 — version drift / missing required files
"""

from __future__ import annotations

import ast
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


REQUIRED_PATHS = [
    "VERSION",
    "run_gui.py",
    "run_parser_orders_cli.py",
    "OgrOK_UA.spec",
    "requirements.txt",
    "CHANGELOG.md",
    "README.md",
    "BUILD_WINDOWS.md",
    "templates/N_fixed.xlsx",
    "config/autofill/mapping.json",
    "apps/parser_orders/src/services/pipeline_service.py",
    "apps/parser_orders/src/services/app_paths.py",
    "apps/parser_orders/src/gui/parser_gui.py",
    "apps/parser_orders/src/gui/dialogs/manual_fields.py",
    "apps/parser_orders/src/gui/dialogs/rule_from_selection.py",
    "apps/parser_orders/src/gui/tabs/input_tab.py",
    "apps/parser_orders/src/gui/tabs/people_tab.py",
    "apps/parser_orders/src/gui/widgets/tags.py",
    "apps/parser_orders/src/gui/widgets/text_styles.py",
    "apps/parser_orders/src/gui/controllers/people_data.py",
    "apps/parser_orders/src/gui/controllers/quality_rules.py",
    "apps/parser_orders/src/core/docx_parser.py",
    "apps/parser_orders/src/core/excel_autofill.py",
    "installer/OgrOK_UA.iss",
    "scripts/build_exe_windows.bat",
    "docs/ARCHITECTURE.md",
    "docs/RELEASE_CHECKLIST_UA.md",
]


def read_version() -> str:
    return (ROOT / "VERSION").read_text(encoding="utf-8").strip()


def check_structure() -> list:
    return [rel for rel in REQUIRED_PATHS if not (ROOT / rel).exists()]


def check_version_sync(version: str) -> list:
    errors = []
    iss = (ROOT / "installer" / "OgrOK_UA.iss").read_text(encoding="utf-8", errors="replace")
    if f'MyAppVersion "{version}"' not in iss:
        errors.append(f'installer/OgrOK_UA.iss: expected MyAppVersion "{version}"')
    try:
        from apps.parser_orders import __version__ as pkg_ver
        if pkg_ver != version:
            errors.append(f"apps.parser_orders.__version__={pkg_ver!r} != VERSION {version!r}")
    except Exception as e:
        errors.append(f"cannot import apps.parser_orders.__version__: {e}")
    readme = (ROOT / "README.md").read_text(encoding="utf-8", errors="replace")
    if version not in readme:
        errors.append(f"README.md does not mention {version}")
    cl = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8", errors="replace")
    if f"## {version}" not in cl:
        errors.append(f"CHANGELOG.md missing section ## {version}")
    bw = (ROOT / "BUILD_WINDOWS.md").read_text(encoding="utf-8", errors="replace")
    if version not in bw:
        errors.append(f"BUILD_WINDOWS.md does not mention {version}")
    spec = (ROOT / "OgrOK_UA.spec").read_text(encoding="utf-8", errors="replace")
    if version not in spec:
        errors.append(f"OgrOK_UA.spec does not mention {version}")
    return errors


def check_syntax_packages() -> list:
    errors = []
    files = []
    for r in [ROOT / "apps" / "parser_orders" / "src", ROOT / "run_gui.py", ROOT / "run_parser_orders_cli.py"]:
        if r.is_file():
            files.append(r)
        elif r.is_dir():
            files.extend(r.rglob("*.py"))
    for fp in files:
        try:
            ast.parse(fp.read_text(encoding="utf-8"))
        except SyntaxError as e:
            errors.append(f"syntax {fp.relative_to(ROOT)}: {e}")
    return errors


def check_config_assets() -> list:
    errors = []
    mapping = ROOT / "config" / "autofill" / "mapping.json"
    try:
        data = json.loads(mapping.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or len(data) < 1:
            errors.append("mapping.json empty or invalid structure")
    except Exception as e:
        errors.append(f"mapping.json: {e}")
    tpl = ROOT / "templates" / "N_fixed.xlsx"
    if not tpl.is_file() or tpl.stat().st_size < 1000:
        errors.append("templates/N_fixed.xlsx missing or too small")
    return errors


def check_critical_imports() -> list:
    errors = []
    try:
        from apps.parser_orders.src.services.pipeline_service import flatten_records, PipelinePaths
        from apps.parser_orders.src.services.app_paths import get_app_paths
        from apps.parser_orders.src.gui.controllers import quality_rules, people_data
        from apps.parser_orders.src.gui.widgets.tags import ui_tag_for_event_and_category
        from apps.parser_orders.src.core.docx_parser import build_combined_v2
        from apps.parser_orders.src.core.excel_autofill import extract_records_from_data

        paths = get_app_paths(str(ROOT))
        assert paths.base_dir
        assert ui_tag_for_event_and_category("arrival", None) == ("ARRIVAL",)
        assert flatten_records({"people": [{"pib": "A B C", "records": [{}]}]})[0]["pib"] == "A B C"
        assert extract_records_from_data({"people": [{"records": [{"x": 1}]}]}) == [{"x": 1}]
        assert "mapping.json" in quality_rules.QUALITY_FILE_MAP
        assert people_data.parse_dt_key("01.01.2024")[0] == 0
        _ = build_combined_v2
        _ = PipelinePaths
    except Exception as e:
        errors.append(f"critical import/logic: {type(e).__name__}: {e}")
    return errors


def run_unit_tests():
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    return unittest.TextTestRunner(verbosity=1).run(suite)


def main() -> int:
    print("=" * 60)
    print("ОгрОК_UA smoke_check (Phase 10+)")
    print("ROOT:", ROOT)
    version = read_version()
    print("VERSION:", version)
    print("=" * 60)
    exit_code = 0

    print("\n[1/5] Structure…")
    missing = check_structure()
    if missing:
        print("  FAIL missing files:")
        for m in missing:
            print("   -", m)
        exit_code = max(exit_code, 2)
    else:
        print(f"  OK ({len(REQUIRED_PATHS)} paths)")

    print("\n[2/5] Version sync…")
    verr = check_version_sync(version)
    if verr:
        print("  FAIL:")
        for e in verr:
            print("   -", e)
        exit_code = max(exit_code, 2)
    else:
        print("  OK ISS / package / README / CHANGELOG / BUILD / spec")

    print("\n[3/5] Syntax (AST)…")
    serr = check_syntax_packages()
    if serr:
        print("  FAIL:")
        for e in serr:
            print("   -", e)
        exit_code = max(exit_code, 1)
    else:
        print("  OK")

    print("\n[4/5] Config + critical imports…")
    cerr = check_config_assets() + check_critical_imports()
    if cerr:
        print("  FAIL:")
        for e in cerr:
            print("   -", e)
        exit_code = max(exit_code, 1)
    else:
        print("  OK mapping, template, pipeline/controllers/tags/core")

    print("\n[5/5] Unit tests…")
    result = run_unit_tests()
    if not result.wasSuccessful():
        exit_code = max(exit_code, 1)
        print("  FAIL unit tests")
    else:
        print(f"  OK ({result.testsRun} tests)")

    print("\n" + "=" * 60)
    if exit_code == 0:
        print(f"SMOKE PASSED — ready for release packaging (v{version})")
    else:
        print(f"SMOKE FAILED — exit {exit_code}")
    print("=" * 60)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
