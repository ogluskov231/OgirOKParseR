@echo off
REM ОгрОК_UA v0.7.1 — збірка Windows .exe (Phase 5: run_gui.py + OgrOK_UA.spec)
cd /d "%~dp0\.."
setlocal

if not exist .venv (
  python -m venv .venv
)

call .venv\Scripts\activate

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

pyinstaller --noconfirm OgrOK_UA.spec

echo.
echo DONE. Реліз: dist\OgrOK_UA\OgrOK_UA.exe
echo Запуск локально без збірки: python run_gui.py
pause
