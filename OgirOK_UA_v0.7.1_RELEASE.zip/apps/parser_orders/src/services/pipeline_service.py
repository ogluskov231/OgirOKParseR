"""DOCX → combined JSON → Excel pipeline without UI dependencies.

Phase 1 refactor: logic extracted from ``parser_gui.App`` so GUI/CLI can call
the same functions. Behaviour matches the previous inline GUI implementation.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class PipelinePaths:
    """Filesystem paths used by parse + autofill steps."""

    template_path: str
    rules_path: str
    mapping_path: str
    learning_dir: str
    output_dir: str
    parsed_dir: str
    diag_path: str
    combined_path: str

    def ensure_dirs(self) -> None:
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.parsed_dir, exist_ok=True)
        diag_parent = os.path.dirname(self.diag_path)
        if diag_parent:
            os.makedirs(diag_parent, exist_ok=True)


@dataclass
class PipelineResult:
    """Outcome of a pipeline run (DOCX or JSON→Excel)."""

    ok: bool
    combined: Optional[Dict[str, Any]] = None
    combined_path: Optional[str] = None
    excel_path: Optional[str] = None
    records_count: int = 0
    processed_files: List[str] = field(default_factory=list)
    errors: List[Dict[str, Any]] = field(default_factory=list)
    error_message: Optional[str] = None
    log_lines: List[str] = field(default_factory=list)


def flatten_records(combined: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten ``people[].records`` the same way GUI/CLI did before Phase 1."""
    records: List[Dict[str, Any]] = []
    for person in combined.get("people") or []:
        if not isinstance(person, dict):
            continue
        pib = person.get("pib") or ""
        for r in person.get("records") or []:
            if not isinstance(r, dict):
                continue
            if not r.get("pib"):
                r["pib"] = pib
            records.append(r)
    return records


def save_combined_json(combined: Dict[str, Any], combined_path: str) -> str:
    """Write combined JSON to disk (UTF-8, indented). Returns path."""
    parent = os.path.dirname(combined_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(combined_path, "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False, indent=2)
    return combined_path


def run_docx_pipeline(docx_files: List[str], paths: PipelinePaths) -> PipelineResult:
    """Parse DOCX list → save combined JSON → autofill Excel.

    Same steps as the former ``App._run_pipeline`` body (without Tk updates).
    """
    from apps.parser_orders.src.core.docx_parser import build_combined_v2
    from apps.parser_orders.src.core.excel_autofill import autofill_template

    result = PipelineResult(ok=False)
    if not docx_files:
        result.error_message = "Список DOCX порожній."
        result.log_lines.append(result.error_message)
        return result

    paths.ensure_dirs()
    result.log_lines.append(f"Парсинг DOCX ({len(docx_files)} файл(ів))...")

    try:
        combined = build_combined_v2(
            docx_files,
            template_path=paths.template_path,
            learning_dir=paths.learning_dir,
        )
    except Exception as e:
        result.error_message = f"Критична помилка парсингу: {e}"
        result.log_lines.append(f"[ERROR] {result.error_message}")
        return result

    result.combined = combined
    processed = combined.get("processed_files") or []
    errors = combined.get("errors") or []
    result.processed_files = list(processed)
    result.errors = list(errors)

    result.log_lines.append(
        f"Успішно оброблено: {len(processed)}; помилок: {len(errors)}"
    )
    for err in errors:
        result.log_lines.append(
            f"[DOCX ERROR] {err.get('file')}: {err.get('error_type')}: {err.get('error')}"
        )

    if not processed and errors:
        result.error_message = (
            "Жоден DOCX не вдалося обробити. Деталі — у журналі обробки."
        )
        return result

    combined_path = paths.combined_path
    try:
        save_combined_json(combined, combined_path)
    except Exception as e:
        result.error_message = f"Не можу зберегти combined JSON: {e}"
        result.log_lines.append(f"[ERROR] {result.error_message}")
        return result

    result.combined_path = combined_path
    result.log_lines.append(f"JSON збережено: {combined_path}")

    records = flatten_records(combined)
    result.records_count = len(records)
    result.log_lines.append("Автозаповнення Excel...")

    try:
        out = autofill_template(
            records,
            template_path=paths.template_path,
            output_dir=paths.output_dir,
            rules_path=paths.rules_path,
            mapping_path=paths.mapping_path,
            diagnostics_path=paths.diag_path,
            learning_dir=paths.learning_dir,
        )
    except Exception as e:
        result.error_message = f"Помилка автозаповнення Excel: {e}"
        result.log_lines.append(f"[ERROR] {result.error_message}")
        # JSON already saved — partial success paths remain set
        return result

    result.excel_path = out
    result.log_lines.append(f"Excel готовий: {out}")
    result.ok = True
    return result


def run_json_autofill(json_path: str, paths: PipelinePaths) -> PipelineResult:
    """Autofill Excel from an existing JSON file (no DOCX parse).

    Same core as the former ``App._run_autofill_from_json_path`` try-block.
    """
    from apps.parser_orders.src.core.excel_autofill import autofill_from_json_file

    result = PipelineResult(ok=False)
    result.log_lines.append(f"Автозаповнення з файлу: {json_path}")

    if not os.path.exists(json_path):
        result.error_message = f"JSON не знайдено: {json_path}"
        result.log_lines.append(f"[ERROR] {result.error_message}")
        return result

    if not os.path.exists(paths.template_path):
        result.error_message = f"Excel-шаблон не знайдено: {paths.template_path}"
        result.log_lines.append(f"[ERROR] {result.error_message}")
        return result

    paths.ensure_dirs()

    try:
        out, n = autofill_from_json_file(
            json_path=json_path,
            template_path=paths.template_path,
            output_dir=paths.output_dir,
            rules_path=paths.rules_path,
            mapping_path=paths.mapping_path,
            diagnostics_path=paths.diag_path,
            learning_dir=paths.learning_dir,
        )
    except FileNotFoundError as e:
        result.error_message = str(e)
        result.log_lines.append(f"[ERROR] {e}")
        return result
    except ValueError as e:
        result.error_message = str(e)
        result.log_lines.append(f"[ERROR] {e}")
        return result
    except Exception as e:
        result.error_message = str(e)
        result.log_lines.append(f"[ERROR] {e}")
        return result

    result.ok = True
    result.excel_path = out
    result.combined_path = json_path
    result.records_count = n
    result.log_lines.append(f"Excel готовий ({n} записів): {out}")
    return result


def paths_from_app_dirs(
    *,
    template_path: str,
    rules_path: str,
    mapping_path: str,
    learning_dir: str,
    output_dir: str,
    parsed_dir: str,
    diag_path: str,
    combined_path: str,
) -> PipelinePaths:
    """Build ``PipelinePaths`` from the same attributes ``App`` already holds."""
    return PipelinePaths(
        template_path=template_path,
        rules_path=rules_path,
        mapping_path=mapping_path,
        learning_dir=learning_dir,
        output_dir=output_dir,
        parsed_dir=parsed_dir,
        diag_path=diag_path,
        combined_path=combined_path,
    )
