"""Central project paths (Phase 8).

Single place for BASE_DIR / config / output / documents so GUI, CLI and
pipeline do not re-implement frozen vs source layout.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass


def resolve_base_dir(project_root: str | None = None) -> str:
    """Directory that contains templates/, config/, input/, output/.

    - Source tree: project root (parent of ``apps/``).
    - PyInstaller frozen: directory of the executable.
    """
    if getattr(sys, "frozen", False):
        try:
            return os.path.dirname(sys.executable)
        except Exception:
            pass
    if project_root:
        return os.path.abspath(project_root)
    # services/app_paths.py -> services -> src -> parser_orders -> apps -> root
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, "..", "..", "..", ".."))


@dataclass(frozen=True)
class AppPaths:
    base_dir: str

    @property
    def templates(self) -> str:
        return os.path.join(self.base_dir, "templates")

    @property
    def config(self) -> str:
        return os.path.join(self.base_dir, "config")

    @property
    def output(self) -> str:
        return os.path.join(self.base_dir, "output")

    @property
    def docs_dir(self) -> str:
        return os.path.join(self.base_dir, "input", "documents")

    @property
    def assets(self) -> str:
        return os.path.join(self.base_dir, "assets")

    @property
    def template_xlsx(self) -> str:
        return os.path.join(self.templates, "N_fixed.xlsx")

    @property
    def mapping_json(self) -> str:
        return os.path.join(self.config, "autofill", "mapping.json")

    @property
    def rules_json(self) -> str:
        return os.path.join(self.config, "autofill", "passport_rules.json")

    @property
    def learning_dir(self) -> str:
        return os.path.join(self.config, "learning")

    @property
    def categories_dir(self) -> str:
        return os.path.join(self.config, "categories")

    @property
    def excel_export_dir(self) -> str:
        return os.path.join(self.output, "exports", "excel")

    @property
    def parsed_dir(self) -> str:
        return os.path.join(self.output, "parsed")

    @property
    def combined_json(self) -> str:
        return os.path.join(self.parsed_dir, "combined_v2.json")

    @property
    def diag_unknowns(self) -> str:
        return os.path.join(self.output, "diagnostics", "unknowns_latest.json")

    def ensure_runtime_dirs(self) -> None:
        for d in (
            self.docs_dir,
            self.excel_export_dir,
            self.parsed_dir,
            os.path.join(self.output, "exports", "txt"),
            os.path.join(self.output, "exports", "json"),
            os.path.join(self.output, "diagnostics"),
            self.categories_dir,
            self.learning_dir,
        ):
            os.makedirs(d, exist_ok=True)


def get_app_paths(project_root: str | None = None) -> AppPaths:
    return AppPaths(base_dir=resolve_base_dir(project_root))
