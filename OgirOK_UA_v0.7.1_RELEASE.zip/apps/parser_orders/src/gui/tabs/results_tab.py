"""Tab builder: results_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App._build_results.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk

from apps.parser_orders.src.core.os_utils import open_path


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    frm = ttk.Frame(app.tab_results, padding=12)
    frm.pack(fill="both", expand=True)

    app.res_excel = tk.StringVar(value="")
    app.res_json = tk.StringVar(value="")
    app.res_diag = tk.StringVar(value=app.diag_path)

    ttk.Label(frm, text="Останній Excel:").grid(row=0, column=0, sticky="w")
    ttk.Entry(frm, textvariable=app.res_excel, width=90).grid(row=1, column=0, sticky="we")
    ttk.Button(frm, text="Відкрити файл", command=app._open_last_excel).grid(row=1, column=1, padx=6)

    ttk.Label(frm, text="Останній JSON:").grid(row=2, column=0, sticky="w", pady=(10,0))
    ttk.Entry(frm, textvariable=app.res_json, width=90).grid(row=3, column=0, sticky="we")
    ttk.Button(frm, text="Відкрити файл", command=app._open_last_json).grid(row=3, column=1, padx=6)

    ttk.Label(frm, text="Діагностика (unknowns):").grid(row=4, column=0, sticky="w", pady=(10,0))
    ttk.Entry(frm, textvariable=app.res_diag, width=90).grid(row=5, column=0, sticky="we")
    ttk.Button(frm, text="Відкрити файл", command=app._open_diag).grid(row=5, column=1, padx=6)

    ttk.Separator(frm).grid(row=6, column=0, columnspan=2, sticky="we", pady=12)

    actions = ttk.Frame(frm)
    actions.grid(row=7, column=0, columnspan=2, sticky="we")
    ttk.Button(actions, text="📂 Відкрити папку Excel", command=lambda: open_path(app.output_dir)).pack(side="left")
    ttk.Button(actions, text="📂 Відкрити output/parsed", command=lambda: open_path(app.parsed_dir)).pack(side="left", padx=8)
    ttk.Button(actions, text="📊 Автозаповнення Excel з JSON", command=app._autofill_from_json_file).pack(side="left", padx=8)
    ttk.Button(actions, text="📊 З combined_v2.json", command=app._autofill_from_combined).pack(side="left", padx=8)

    frm.columnconfigure(0, weight=1)
