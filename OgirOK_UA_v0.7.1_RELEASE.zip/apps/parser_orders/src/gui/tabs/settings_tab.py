"""Tab builder: settings_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App._build_settings.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

from apps.parser_orders.src.core.os_utils import open_path


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    frm = ttk.Frame(app.tab_settings, padding=12)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Шаблон Excel (N_fixed.xlsx):").grid(row=0, column=0, sticky="w")
    app.tpl_var = tk.StringVar(value=app.template_path)
    ttk.Entry(frm, textvariable=app.tpl_var, width=90).grid(row=1, column=0, sticky="we")
    ttk.Button(frm, text="Обрати", command=app._pick_template).grid(row=1, column=1, padx=6)

    ttk.Label(frm, text="Папка з DOCX за замовчуванням:").grid(row=2, column=0, sticky="w", pady=(10,0))
    docs_dir = os.path.abspath(os.path.join(_output_root(app), os.pardir, "input", "documents"))
    # Prefer input/documents next to project output root's parent
    if not os.path.isdir(docs_dir):
        docs_dir = os.path.abspath(os.path.join(os.path.dirname(app.template_path), os.pardir, "input", "documents"))
    app.docs_var = tk.StringVar(value=docs_dir)
    ttk.Entry(frm, textvariable=app.docs_var, width=90).grid(row=3, column=0, sticky="we")
    ttk.Button(frm, text="Відкрити", command=lambda: open_path(app.docs_var.get())).grid(row=3, column=1, padx=6)

    ttk.Label(frm, text="Вихід Excel:").grid(row=4, column=0, sticky="w", pady=(10,0))
    app.out_var = tk.StringVar(value=app.output_dir)
    ttk.Entry(frm, textvariable=app.out_var, width=90).grid(row=5, column=0, sticky="we")
    ttk.Button(frm, text="Відкрити", command=lambda: open_path(app.output_dir)).grid(row=5, column=1, padx=6)

    ttk.Separator(frm).grid(row=6, column=0, columnspan=2, sticky="we", pady=12)
    ttk.Button(frm, text="Застосувати (шаблон/вихід)", command=app._apply_settings).grid(row=7, column=0, sticky="w")

    # --- UI settings (font + highlight colors)
    ui = ttk.LabelFrame(frm, text="UI — шрифт + підсвітка", padding=10)
    ui.grid(row=8, column=0, columnspan=2, sticky="nsew", pady=(12, 0))

    cur_font = app.ui_settings.get("font") or {}
    app.ui_font_family_var = tk.StringVar(value=cur_font.get("family") or "")
    app.ui_font_size_var = tk.StringVar(value=str(cur_font.get("size") or 12))
    app.ui_wrap_var = tk.BooleanVar(value=bool(app.ui_settings.get("wrap_person_text", True)))

    ttk.Label(ui, text="Font family:").grid(row=0, column=0, sticky="w")
    fam_values = sorted({f for f in tkfont.families() if f})
    fam_box = ttk.Combobox(ui, textvariable=app.ui_font_family_var, values=fam_values, width=34)
    fam_box.grid(row=0, column=1, sticky="w", padx=(8, 0))

    ttk.Label(ui, text="Size:").grid(row=0, column=2, sticky="w", padx=(18, 0))
    size_sp = ttk.Spinbox(ui, from_=8, to=28, textvariable=app.ui_font_size_var, width=5)
    size_sp.grid(row=0, column=3, sticky="w", padx=(8, 0))

    ttk.Checkbutton(ui, text="Wrap (person text)", variable=app.ui_wrap_var).grid(row=0, column=4, sticky="w", padx=(18, 0))

    ttk.Separator(ui).grid(row=1, column=0, columnspan=5, sticky="we", pady=10)

    ttk.Label(ui, text="Кольори підсвітки:").grid(row=2, column=0, sticky="w")
    colors = app.ui_settings.get("colors") or {}
    app._ui_color_buttons = {}
    tags = [
        ("BLOCK_ACTIVE", "Block"),
        ("MATCH_ACTIVE", "Match"),
        ("CAT_MATCH", "Category"),
        ("PIB_MATCH", "PIB"),
        ("FIND", "Find"),
    ]
    row = 3
    col = 0
    for tag, label in tags:
        if col >= 5:
            row += 1
            col = 0
        b = tk.Button(ui, text=label, width=10, relief="raised",
                      bg=colors.get(tag, "#dddddd"),
                      command=lambda t=tag: app._pick_ui_color(t))
        b.grid(row=row, column=col, sticky="w", padx=(0, 8), pady=(4, 4))
        app._ui_color_buttons[tag] = b
        col += 1

    btn_row = row + 1
    ttk.Button(ui, text="Застосувати UI", command=app._apply_ui_settings_from_controls).grid(row=btn_row, column=0, sticky="w", pady=(10, 0))
    ttk.Button(ui, text="Скинути кольори", command=app._reset_ui_colors).grid(row=btn_row, column=1, sticky="w", pady=(10, 0))

    ui.columnconfigure(1, weight=1)
    frm.columnconfigure(0, weight=1)
