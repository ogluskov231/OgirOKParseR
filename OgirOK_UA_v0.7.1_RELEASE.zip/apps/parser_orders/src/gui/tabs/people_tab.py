"""Tab builder: people_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App.build_people.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

from apps.parser_orders.src.core.os_utils import open_path
from apps.parser_orders.src.gui.widgets import text_styles as ui_styles


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    frm = ttk.Frame(app.tab_people, padding=12)
    frm.pack(fill="both", expand=True)

    # --- toolbar
    top = ttk.Frame(frm)
    top.pack(fill="x", pady=(0, 8))

    ttk.Button(top, text="⮜/⮞", width=5, command=app._toggle_people_sidebar).pack(side="left")
    ttk.Button(top, text="🔄 Оновити список (A–Я)", command=app.refresh_people_view).pack(side="left")
    ttk.Button(top, text="🗑 Видалити зі списку", command=app.hide_selected_person).pack(side="left", padx=6)
    ttk.Button(top, text="↩ Повернути до списку", command=app.restore_person_to_list).pack(side="left", padx=6)
    ttk.Button(top, text="💾 TXT (людина)", command=app.export_person_txt).pack(side="left", padx=6)
    ttk.Button(top, text="💾 JSON (людина)", command=app.export_person_json).pack(side="left")
    ttk.Button(top, text="📦 Експорт ВСІХ (ZIP)", command=app.export_all_people_zip).pack(side="left", padx=6)
    ttk.Separator(top, orient="vertical").pack(side="left", fill="y", padx=10)
    ttk.Button(top, text="📄 Відкрити DOCX джерело", command=app.open_selected_docx_source).pack(side="left")
    ttk.Button(top, text="🗎 Оригінал (людина)", command=app.open_person_original_view).pack(side="left", padx=6)
    ttk.Button(top, text="🏷 Перегляд по категоріях", command=app.open_category_browser).pack(side="left")
    ttk.Separator(top, orient="vertical").pack(side="left", fill="y", padx=10)
    ttk.Button(top, text="➕ Правило з виділення", command=app._add_rule_from_selection).pack(side="left")
    ttk.Button(top, text="🔧 Ручний розбір полів", command=app._manual_field_parse).pack(side="left", padx=6)
    ttk.Button(top, text="📊 Excel з JSON", command=app._autofill_from_combined).pack(side="left", padx=6)
    ttk.Button(top, text="🧾 Правила", command=app.open_user_category_rules_manager).pack(side="left", padx=6)

    ttk.Label(top, text="Пошук ПІБ:").pack(side="left", padx=(18, 4))
    app.people_filter = tk.StringVar(value="")
    ent = ttk.Entry(top, textvariable=app.people_filter, width=28)
    ent.pack(side="left")
    ent.bind("<KeyRelease>", lambda e: app.apply_people_filter())

    # --- layout: left sidebar + right content
    body = ttk.Panedwindow(frm, orient="horizontal")
    body.pack(fill="both", expand=True)

    left = ttk.Frame(body)
    right = ttk.Frame(body)
    body.add(left, weight=1)
    body.add(right, weight=3)

    # store for collapse/expand
    app._people_paned = body
    app._people_left = left
    app._people_right = right
    app._people_sidebar_collapsed = False

    # helper: create treeview with both scrollbars
    def _mk_tree(parent, height: int, show: str, columns: tuple[str, ...]):
        box = ttk.Frame(parent)
        tree = ttk.Treeview(box, columns=columns, show=show, height=height)
        ysb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(box, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        return box, tree

    # LEFT: people list (tree) + per-person doc list
    ttk.Label(left, text="ПІБ (алфавіт):").pack(anchor="w")
    people_box, app.people_tree = _mk_tree(left, height=18, show="headings", columns=("pib", "blocks", "records"))
    people_box.pack(fill="both", expand=True)
    app.people_tree.heading("pib", text="ПІБ")
    app.people_tree.heading("blocks", text="Блоки")
    app.people_tree.heading("records", text="Записи")
    app.people_tree.column("pib", width=240)
    app.people_tree.column("blocks", width=60, anchor="center")
    app.people_tree.column("records", width=60, anchor="center")
    app.people_tree.bind("<<TreeviewSelect>>", lambda e: app.show_selected_person())
    app.people_tree.bind("<Delete>", lambda e: app.hide_selected_person())

    docs_box = ttk.Frame(left)
    docs_box.pack(fill="both", expand=False, pady=(10, 0))
    ttk.Label(docs_box, text="Документи цієї людини:").pack(anchor="w")
    docs_tree_box, app.docs_tree = _mk_tree(docs_box, height=9, show="tree headings", columns=("count",))
    docs_tree_box.pack(fill="both", expand=True)
    app.docs_tree.heading("#0", text="DOCX / Блок")
    app.docs_tree.heading("count", text="К-сть")
    app.docs_tree.column("#0", width=260)
    app.docs_tree.column("count", width=60, anchor="center")
    app.docs_tree.bind("<<TreeviewSelect>>", lambda e: app._on_docs_tree_select())
    app.docs_tree.bind("<Double-1>", lambda e: app._on_docs_tree_open_or_jump())

    cats_box = ttk.Frame(left)
    cats_box.pack(fill="both", expand=False, pady=(10, 0))
    ttk.Label(cats_box, text="Категорії (Надійшло/Вибуло):").pack(anchor="w")
    cats_tree_box, app.cats_tree = _mk_tree(cats_box, height=9, show="tree headings", columns=("count",))
    cats_tree_box.pack(fill="both", expand=True)
    app.cats_tree.heading("#0", text="Категорія")
    app.cats_tree.heading("count", text="К-сть")
    app.cats_tree.column("#0", width=260)
    app.cats_tree.column("count", width=60, anchor="center")
    app.cats_tree.bind("<<TreeviewSelect>>", lambda e: app._on_cats_tree_select())

    cat_btns = ttk.Frame(cats_box)
    cat_btns.pack(fill="x", pady=(6, 0))
    ttk.Button(cat_btns, text="✖ Скинути категорію", command=app._clear_category_filter).pack(side="left")


    # RIGHT: text + fragments
    right_top = ttk.Frame(right)
    right_top.pack(fill="x")
    ttk.Label(right_top, text="Повʼязаний текст (повні блоки наказів):").pack(side="left")
    ttk.Label(right_top, text="Пошук у тексті:").pack(side="left", padx=(18, 4))
    app.find_var = tk.StringVar(value="")
    find_ent = ttk.Entry(right_top, textvariable=app.find_var, width=28)
    find_ent.pack(side="left")
    ttk.Button(right_top, text="⬇", width=3, command=lambda: app.find_in_person_text(next_=True)).pack(side="left", padx=2)
    ttk.Button(right_top, text="⬆", width=3, command=lambda: app.find_in_person_text(next_=False)).pack(side="left", padx=2)
    ttk.Button(right_top, text="🧹", width=3, command=app.clear_find_highlight).pack(side="left", padx=2)

    ttk.Separator(right_top, orient="vertical").pack(side="left", fill="y", padx=10)
    ttk.Button(right_top, text="A-", width=3, command=lambda: app._adjust_font_size(-1)).pack(side="left")
    ttk.Button(right_top, text="A+", width=3, command=lambda: app._adjust_font_size(1)).pack(side="left", padx=2)
    ttk.Button(right_top, text="↔", width=3, command=app._toggle_person_wrap).pack(side="left", padx=(6, 0))

    # Vertical split
    vpan = ttk.Panedwindow(right, orient="vertical")
    vpan.pack(fill="both", expand=True, pady=(6, 0))

    text_frame = ttk.Frame(vpan)
    bottom_frame = ttk.Frame(vpan)
    vpan.add(text_frame, weight=3)
    vpan.add(bottom_frame, weight=2)

    wrap_mode = "word" if bool(app.ui_settings.get("wrap_person_text", True)) else "none"
    app.person_text = tk.Text(text_frame, wrap=wrap_mode)
    app._apply_text_widget_style(app.person_text)
    txt_ysb = ttk.Scrollbar(text_frame, orient="vertical", command=app.person_text.yview)
    txt_xsb = ttk.Scrollbar(text_frame, orient="horizontal", command=app.person_text.xview)
    app.person_text.configure(yscrollcommand=txt_ysb.set, xscrollcommand=txt_xsb.set)
    app.person_text.grid(row=0, column=0, sticky="nsew")
    txt_ysb.grid(row=0, column=1, sticky="ns")
    txt_xsb.grid(row=1, column=0, sticky="ew")
    text_frame.rowconfigure(0, weight=1)
    text_frame.columnconfigure(0, weight=1)

    # Tags for interaction (Phase 4: widgets/text_styles)
    bold = ui_styles.reconfigure_people_text_tags(app.person_text, app.ui_settings)
    if bold is not None:
        app._font_bold = bold
    # event-row colors on person_text as well
    ui_styles.apply_tree_event_tags(app.person_text, app.ui_settings)  # tag_configure works on Text too for names

    app.person_text.bind("<Button-3>", app._person_text_context_menu)

    # Bottom: fragments table
    ttk.Label(bottom_frame, text="Фрагменти / блоки (double-click → перейти в текст):").pack(anchor="w")
    frag_box = ttk.Frame(bottom_frame)
    frag_box.pack(fill="both", expand=True)
    app.frag_tree = ttk.Treeview(
        frag_box,
        columns=("idx", "date", "event", "category", "doc", "block", "snippet"),
        show="headings",
        height=10,
    )
    for col, title, w in [
        ("idx", "#", 40),
        ("date", "Дата", 90),
        ("event", "Подія", 80),
        ("category", "Категорія", 200),
        ("doc", "DOCX", 180),
        ("block", "Блок", 60),
        ("snippet", "Snippet", 520),
    ]:
        app.frag_tree.heading(col, text=title)
        app.frag_tree.column(col, width=w, anchor=("center" if col in ("idx", "block") else "w"))
    frag_ysb = ttk.Scrollbar(frag_box, orient="vertical", command=app.frag_tree.yview)
    frag_xsb = ttk.Scrollbar(frag_box, orient="horizontal", command=app.frag_tree.xview)
    app.frag_tree.configure(yscrollcommand=frag_ysb.set, xscrollcommand=frag_xsb.set)
    app.frag_tree.grid(row=0, column=0, sticky="nsew")
    frag_ysb.grid(row=0, column=1, sticky="ns")
    frag_xsb.grid(row=1, column=0, sticky="ew")
    frag_box.rowconfigure(0, weight=1)
    frag_box.columnconfigure(0, weight=1)
    app.frag_tree.bind("<Double-1>", lambda e: app.jump_to_selected_fragment())
    app.frag_tree.bind("<<TreeviewSelect>>", lambda e: app.jump_to_selected_fragment())

    # Row coloring by event_type (Phase 4 helpers)
    try:
        ui_styles.apply_tree_event_tags(app.frag_tree, app.ui_settings)
        if hasattr(app, "docs_tree"):
            ui_styles.apply_tree_event_tags(app.docs_tree, app.ui_settings)
        if hasattr(app, "people_tree"):
            ui_styles.apply_tree_event_tags(app.people_tree, app.ui_settings)
            c = app.ui_settings.get("colors") or {}
            app.people_tree.tag_configure("BOTH", background=c.get("EVT_BOTH", "#fff3bf"))
    except Exception:
        pass

    # Internal caches
    app._people_cache = {}  # pib -> person dict
    app._people_all_pibs = []
    app._people_filtered_pibs = []
    app._frag_meta = {}  # tree item -> meta
    app._docs_meta = {}  # docs_tree item -> meta (doc or block)
    app._doc_tree_meta = {}  # docs_tree item -> meta
