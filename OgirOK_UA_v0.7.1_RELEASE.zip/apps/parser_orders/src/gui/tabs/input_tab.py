"""Tab builder: input_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App._build_input.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk

from apps.parser_orders.src.core.os_utils import open_path


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    frm = ttk.Frame(app.tab_input, padding=12)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Джерело DOCX (файл або папка). Якщо не вибрати — береться input/documents/").grid(row=0, column=0, sticky="w")
    ttk.Entry(frm, textvariable=app.selected_path, width=90).grid(row=1, column=0, sticky="we", padx=(0,8))
    btns = ttk.Frame(frm)
    btns.grid(row=1, column=1, sticky="e")
    ttk.Button(btns, text="📄 Файл", command=app._pick_file).pack(side="left", padx=4)
    ttk.Button(btns, text="📁 Папка", command=app._pick_folder).pack(side="left", padx=4)
    ttk.Button(btns, text="🔍 Сканувати", command=app._scan).pack(side="left", padx=4)

    tree_frame = ttk.Frame(frm)
    tree_frame.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=10)

    app.tree = ttk.Treeview(tree_frame, columns=("path",), show="headings", height=22)
    app.tree.heading("path", text="Знайдені DOCX")
    app.tree.column("path", width=900)
    ysb = ttk.Scrollbar(tree_frame, orient="vertical", command=app.tree.yview)
    xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=app.tree.xview)
    app.tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
    app.tree.grid(row=0, column=0, sticky="nsew")
    ysb.grid(row=0, column=1, sticky="ns")
    xsb.grid(row=1, column=0, sticky="ew")
    tree_frame.rowconfigure(0, weight=1)
    tree_frame.columnconfigure(0, weight=1)

    frm.rowconfigure(2, weight=1)
    frm.columnconfigure(0, weight=1)

    actions = ttk.Frame(frm)
    actions.grid(row=3, column=0, columnspan=2, sticky="we")
    ttk.Button(actions, text="⚡ Обробити все (input/documents)", command=app._run_default).pack(side="left")
    ttk.Button(actions, text="▶ Обробити вибране", command=app._run_selected).pack(side="left", padx=8)
    ttk.Separator(actions, orient="vertical").pack(side="left", fill="y", padx=10)
    ttk.Button(actions, text="📊 Excel з JSON-файлу", command=app._autofill_from_json_file).pack(side="left")
    ttk.Button(actions, text="📊 З combined_v2.json", command=app._autofill_from_combined).pack(side="left", padx=8)
