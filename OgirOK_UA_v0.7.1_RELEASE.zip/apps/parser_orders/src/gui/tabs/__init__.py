"""Notebook tab builders (Phase 3)."""

from apps.parser_orders.src.gui.tabs import input_tab, run_tab, results_tab, quality_tab, people_tab, settings_tab

__all__ = [
    "input_tab",
    "run_tab",
    "results_tab",
    "quality_tab",
    "people_tab",
    "settings_tab",
]
