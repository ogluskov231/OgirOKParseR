"""Tab builder: quality_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App._build_quality_rules.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk

from apps.parser_orders.src.core.os_utils import open_path


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    """Manage JSON files that directly influence parser quality/accuracy."""
    frm = ttk.Frame(app.tab_quality, padding=12)
    frm.pack(fill="both", expand=True)

    ttk.Label(
        frm,
        text=(
            "JSON-файли правил та конфігурацій, які використовує парсер. "
            "Завантаження замінює відповідний файл у config/. Перед заміною "
            "автоматично створюється резервна копія."
        ),
        wraplength=1000,
        justify="left"
    ).grid(row=0, column=0, columnspan=4, sticky="we", pady=(0, 10))

    cols = ("file", "destination", "status")
    app.quality_tree = ttk.Treeview(frm, columns=cols, show="headings", height=18)
    app.quality_tree.heading("file", text="JSON-файл")
    app.quality_tree.heading("destination", text="Призначення")
    app.quality_tree.heading("status", text="Стан")
    app.quality_tree.column("file", width=260, anchor="w")
    app.quality_tree.column("destination", width=460, anchor="w")
    app.quality_tree.column("status", width=180, anchor="w")
    app.quality_tree.grid(row=1, column=0, columnspan=3, sticky="nsew")

    ysb = ttk.Scrollbar(frm, orient="vertical", command=app.quality_tree.yview)
    ysb.grid(row=1, column=3, sticky="ns")
    app.quality_tree.configure(yscrollcommand=ysb.set)

    actions = ttk.Frame(frm)
    actions.grid(row=2, column=0, columnspan=4, sticky="we", pady=(10, 6))
    ttk.Button(actions, text="📥 Завантажити JSON", command=app._import_quality_json).pack(side="left", padx=(0, 6))
    ttk.Button(actions, text="🔍 Перевірити всі", command=app._validate_quality_jsons).pack(side="left", padx=6)
    ttk.Button(actions, text="📤 Експортувати всі", command=app._export_quality_jsons).pack(side="left", padx=6)
    ttk.Button(actions, text="📂 Відкрити config", command=lambda: open_path(_config_dir(app))).pack(side="left", padx=6)
    ttk.Button(actions, text="🔄 Оновити", command=app._refresh_quality_tree).pack(side="right")

    info = ttk.LabelFrame(frm, text="Файли, що впливають на парсинг / класифікацію / автозаповнення", padding=8)
    info.grid(row=3, column=0, columnspan=4, sticky="we", pady=(6, 0))
    app.quality_info = tk.Text(info, height=7, wrap="word")
    app._apply_text_widget_style(app.quality_info)
    app.quality_info.pack(fill="both", expand=True)
    app.quality_info.insert("1.0", app._quality_files_help_text())
    app.quality_info.configure(state="disabled")

    frm.rowconfigure(1, weight=1)
    frm.columnconfigure(1, weight=1)
    app._refresh_quality_tree()
