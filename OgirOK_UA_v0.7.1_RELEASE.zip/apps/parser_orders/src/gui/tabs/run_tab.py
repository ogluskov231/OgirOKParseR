"""Tab builder: run_tab (Phase 3).

Constructs UI on ``app.tab_*`` and binds commands to App methods.
Behaviour is unchanged from the former App._build_run.
"""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk

from apps.parser_orders.src.core.os_utils import open_path


def _config_dir(app) -> str:
    return os.path.dirname(app.learning_dir)


def _output_root(app) -> str:
    # parsed_dir = output/parsed
    return os.path.abspath(os.path.join(app.parsed_dir, os.pardir))


def build(app) -> None:
    frm = ttk.Frame(app.tab_run, padding=12)
    frm.pack(fill="both", expand=True)

    app.status_var = tk.StringVar(value="Готово")
    ttk.Label(frm, textvariable=app.status_var).pack(anchor="w")

    app.pb = ttk.Progressbar(frm, orient="horizontal", mode="determinate", maximum=100)
    app.pb.pack(fill="x", pady=6)

    log_frame = ttk.Frame(frm)
    log_frame.pack(fill="both", expand=True, pady=8)
    app.log = tk.Text(log_frame, height=28, wrap="none")
    app._apply_text_widget_style(app.log)
    ysb = ttk.Scrollbar(log_frame, orient="vertical", command=app.log.yview)
    xsb = ttk.Scrollbar(log_frame, orient="horizontal", command=app.log.xview)
    app.log.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
    app.log.grid(row=0, column=0, sticky="nsew")
    ysb.grid(row=0, column=1, sticky="ns")
    xsb.grid(row=1, column=0, sticky="ew")
    log_frame.rowconfigure(0, weight=1)
    log_frame.columnconfigure(0, weight=1)

    bottom = ttk.Frame(frm)
    bottom.pack(fill="x")
    ttk.Button(bottom, text="🧹 Очистити лог", command=lambda: app.log.delete("1.0","end")).pack(side="left")
    ttk.Button(bottom, text="📂 Відкрити output", command=lambda: open_path(_output_root(app))).pack(side="left", padx=6)
    ttk.Button(bottom, text="📊 Excel з JSON-файлу", command=app._autofill_from_json_file).pack(side="left", padx=6)
