import os, sys, json, time, zipfile, re, hashlib
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, colorchooser
import tkinter.font as tkfont

# Ensure project root is on sys.path (so `import apps...` works even when running as a script)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from apps.parser_orders.src.core.diagnostics import load_unknowns
from apps.parser_orders.src.core.category_engine import CategoryEngine, make_regex_from_phrase
from apps.parser_orders.src.core.os_utils import open_path
from apps.parser_orders.src.services.pipeline_service import (
    paths_from_app_dirs,
    run_docx_pipeline,
    run_json_autofill,
)
from apps.parser_orders.src.gui.dialogs.rule_from_selection import open_rule_from_selection_dialog
from apps.parser_orders.src.gui.dialogs.manual_fields import (
    open_manual_fields_dialog,
    find_record_for_mention,
    load_combined_json,
)
from apps.parser_orders.src.gui.tabs import (
    input_tab,
    run_tab,
    results_tab,
    quality_tab,
    people_tab,
    settings_tab,
)
from apps.parser_orders.src.gui.widgets.tags import (
    SPECIAL_CATEGORY_TAGS,
    DEFAULT_HIGHLIGHT_COLORS,
    ui_tag_for_event_and_category,
)
from apps.parser_orders.src.gui.widgets import text_styles as ui_styles
from apps.parser_orders.src.services.app_paths import get_app_paths
from apps.parser_orders.src.gui.controllers import quality_rules as quality_ctl
from apps.parser_orders.src.gui.controllers import people_data as people_ctl

# Back-compat alias used across App methods
_ui_tag_for_event_and_category = ui_tag_for_event_and_category

# Phase 8: centralized paths (frozen-aware)
_PATHS = get_app_paths(PROJECT_ROOT)
BASE_DIR = _PATHS.base_dir
TEMPLATES = _PATHS.templates
CONFIG = _PATHS.config
OUTPUT = _PATHS.output
DOCS_DIR = _PATHS.docs_dir


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ОгрОК_UA — Парсер наказів (DOCX → Excel)")
        self.geometry("1100x760")

        # App icon (assets/icon.png). Keep a reference in self to avoid GC.
        try:
            _ip = os.path.join(BASE_DIR, "assets", "icon.png")
            if os.path.exists(_ip):
                self._app_icon = tk.PhotoImage(file=_ip)
                self.iconphoto(True, self._app_icon)
        except Exception:
            pass


        # UI settings (font + highlight colors)
        self.ui_settings_path = os.path.join(CONFIG, "ui_settings.json")
        self.ui_settings = self._load_ui_settings()
        self._apply_global_style()

        self.template_path = os.path.join(TEMPLATES, "N_fixed.xlsx")
        self.rules_path = os.path.join(CONFIG, "autofill", "passport_rules.json")
        self.mapping_path = os.path.join(CONFIG, "autofill", "mapping.json")
        self.template_sources_path = os.path.join(CONFIG, "autofill", "template_sources.json")
        try:
            from apps.parser_orders.src.core.excel_autofill import ensure_mapping_file
            ensure_mapping_file(self.mapping_path, self.template_sources_path)
        except Exception:
            # mapping may be user-managed; do not block GUI startup
            pass
        self.learning_dir = os.path.join(CONFIG, "learning")
        self.categories_dir = os.path.join(CONFIG, "categories")
        os.makedirs(self.categories_dir, exist_ok=True)
        self.category_rules_path = os.path.join(self.categories_dir, "event_categories_rules_v1.json")
        self.user_category_rules_path = os.path.join(self.categories_dir, "user_category_rules.json")
        self._cat_engine = None
        # Hidden people (remove from list)
        self.ignored_people_path = os.path.join(CONFIG, "ignored_people.json")
        self._ignored_people = self._load_ignored_people()

        self.diag_path = os.path.join(OUTPUT, "diagnostics", "unknowns_latest.json")
        self.output_dir = os.path.join(OUTPUT, "exports", "excel")
        self.parsed_dir = os.path.join(OUTPUT, "parsed")
        os.makedirs(self.parsed_dir, exist_ok=True)
        self.combined_path = os.path.join(self.parsed_dir, "combined_v2.json")
        self.exports_txt_dir = os.path.join(OUTPUT, "exports", "txt")
        self.exports_json_dir = os.path.join(OUTPUT, "exports", "json")
        os.makedirs(self.exports_txt_dir, exist_ok=True)
        os.makedirs(self.exports_json_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)

        self.selected_path = tk.StringVar(value="")
        self.last_excel = None
        self.last_json = None

        # People tab caches
        self._docx_by_name_cache = {}  # doc_name -> full path
        self._current_person_pib = None
        self._current_doc_filter = None  # doc_name or None
        self._current_event_filter = None  # 'arrival'/'departure'/None
        self._current_category_filter = None  # category label or None
        self._mention_pos = {}  # (doc, block_id) -> dict(text indices)

        self._ensure_category_engine()


        nb = ttk.Notebook(self)
        self.nb = nb
        nb.pack(fill="both", expand=True)

        self.tab_input = ttk.Frame(nb)
        self.tab_run = ttk.Frame(nb)
        self.tab_results = ttk.Frame(nb)
        self.tab_quality = ttk.Frame(nb)
        self.tab_settings = ttk.Frame(nb)
        self.tab_people = ttk.Frame(nb)

        nb.add(self.tab_input, text="1) Вхід")
        nb.add(self.tab_run, text="2) Обробка")
        nb.add(self.tab_results, text="3) Результати")
        nb.add(self.tab_people, text="👤 Люди (A–Я)")
        nb.add(self.tab_quality, text="🧩 Правила парсера")
        nb.add(self.tab_settings, text="⚙ Налаштування")

        self._build_input()
        self._build_run()
        self._build_results()
        self.build_people()
        self._build_quality_rules()
        self._build_settings()

        self._scan_default()
        self.after(300, self._auto_run_if_docs)

    # ---------- Input
    def _build_input(self):
        input_tab.build(self)

    def _pick_file(self):
        p = filedialog.askopenfilename(filetypes=[("DOCX","*.docx")])
        if p:
            self.selected_path.set(p)
            self._scan()

    def _pick_folder(self):
        p = filedialog.askdirectory()
        if p:
            self.selected_path.set(p)
            self._scan()

    def _collect_docx(self, path):
        if not path:
            path = DOCS_DIR
        files = []
        if os.path.isfile(path) and path.lower().endswith(".docx"):
            return [path]
        if os.path.isdir(path):
            for root, dirs, fs in os.walk(path):
                # Ignore common temporary/system directories.
                dirs[:] = [d for d in dirs if d not in {"__pycache__", ".git", ".idea", "node_modules"}]
                for f in fs:
                    # Word temporary lock files start with ~$ and are not valid input documents.
                    if f.startswith("~$"):
                        continue
                    if f.lower().endswith(".docx"):
                        files.append(os.path.normpath(os.path.join(root, f)))
        # Avoid duplicate paths when a caller supplies overlapping sources.
        return sorted(set(files), key=lambda x: x.lower())

    def _scan_default(self):
        self.selected_path.set("")
        self._scan()

    def _scan(self):
        path = self.selected_path.get().strip()
        files = self._collect_docx(path)
        for i in self.tree.get_children():
            self.tree.delete(i)
        for f in files:
            self.tree.insert("", "end", values=(f,))
        self.status_var.set(f"Знайдено DOCX: {len(files)}")

    # ---------- Run
    def _build_run(self):
        run_tab.build(self)

    def _log(self, s):
        self.log.insert("end", s + "\n")
        self.log.see("end")
        self.update_idletasks()

    # ---------- UI settings (font + highlight colors) — Phase 4: widgets/text_styles
    def _load_ui_settings(self) -> dict:
        """Load UI settings from config/ui_settings.json."""
        return ui_styles.load_ui_settings(self.ui_settings_path)

    def _save_ui_settings(self) -> None:
        ui_styles.save_ui_settings(self.ui_settings_path, self.ui_settings)


    def _load_ignored_people(self) -> set:
        """Load hidden people list from config/ignored_people.json."""
        path = getattr(self, "ignored_people_path", None)
        if not path or not os.path.exists(path):
            return set()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return set(str(x).strip() for x in data if str(x).strip())
        except Exception:
            return set()
        return set()

    def _save_ignored_people(self):
        """Persist hidden people list."""
        path = getattr(self, "ignored_people_path", None)
        if not path:
            return
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(sorted(self._ignored_people), f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def hide_selected_person(self):
        """Hide selected person from the People list without deleting parsed data."""
        pib = self._get_selected_pib()
        if not pib:
            messagebox.showwarning("Нема вибору", "Оберіть людину зі списку.")
            return
        self._ignored_people.add(pib)
        self._save_ignored_people()
        self.apply_people_filter(select_first=True)

    def restore_person_to_list(self):
        """Restore one or more hidden people to the visible People list."""
        hidden = sorted(self._ignored_people, key=lambda x: x.upper())
        if not hidden:
            messagebox.showinfo("Список порожній", "Немає прихованих людей для повернення.")
            return

        win = tk.Toplevel(self)
        win.title("Повернути до списку")
        win.geometry("620x430")
        win.transient(self)
        win.grab_set()

        outer = ttk.Frame(win, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(
            outer,
            text="Виберіть людину або декілька людей, яких потрібно повернути до списку:"
        ).pack(anchor="w", pady=(0, 8))

        box = ttk.Frame(outer)
        box.pack(fill="both", expand=True)
        tree = ttk.Treeview(box, columns=("pib",), show="headings", selectmode="extended")
        tree.heading("pib", text="ПІБ")
        tree.column("pib", width=540, anchor="w")
        ysb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ysb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)

        for pib in hidden:
            tree.insert("", "end", values=(pib,))

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(10, 0))

        def restore_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Нема вибору", "Оберіть хоча б одну людину.", parent=win)
                return
            restored = []
            for iid in selected:
                vals = tree.item(iid, "values")
                if vals:
                    pib = str(vals[0]).strip()
                    if pib in self._ignored_people:
                        self._ignored_people.remove(pib)
                        restored.append(pib)
            self._save_ignored_people()
            self.apply_people_filter(select_first=True)
            win.destroy()
            messagebox.showinfo("Повернення", f"Повернуто до списку: {len(restored)}", parent=self)

        ttk.Button(btns, text="↩ Повернути вибране", command=restore_selected).pack(side="left")
        ttk.Button(btns, text="Скасувати", command=win.destroy).pack(side="right")
    def _apply_global_style(self) -> None:
        """Apply font to ttk widgets (Phase 4: widgets/text_styles)."""
        ui_styles.apply_global_style(self, self.ui_settings)

    def _apply_text_widget_style(self, widget: tk.Widget) -> None:
        ui_styles.apply_text_widget_style(widget, self.ui_settings)

    def _auto_run_if_docs(self):
        files = self._collect_docx(DOCS_DIR)
        if files:
            # auto-run only when nothing selected
            if not self.selected_path.get().strip():
                self._log("[AUTO] Знайдено DOCX у input/documents — запускаю обробку.")
                self._run_pipeline(files)

    def _run_default(self):
        files = self._collect_docx(DOCS_DIR)
        if not files:
            messagebox.showwarning("Немає DOCX", "Покладіть DOCX у input/documents/")
            return
        self._run_pipeline(files)

    def _run_selected(self):
        path = self.selected_path.get().strip()
        files = self._collect_docx(path)
        if not files:
            messagebox.showwarning("Немає DOCX", "Не знайдено DOCX у вибраному шляху.")
            return
        self._run_pipeline(files)

    def _pipeline_paths(self):
        """Build PipelinePaths from current App path attributes (Phase 1)."""
        return paths_from_app_dirs(
            template_path=self.template_path,
            rules_path=self.rules_path,
            mapping_path=self.mapping_path,
            learning_dir=self.learning_dir,
            output_dir=self.output_dir,
            parsed_dir=self.parsed_dir,
            diag_path=self.diag_path,
            combined_path=self.combined_path,
        )

    def _run_pipeline(self, docx_files):
        # UI shell around pipeline_service.run_docx_pipeline (behaviour unchanged)
        self.pb["value"] = 0
        self.status_var.set(f"Парсинг DOCX: {len(docx_files)}")
        self._log(f"Парсинг DOCX ({len(docx_files)} файл(ів))...")
        self.update()

        result = run_docx_pipeline(docx_files, self._pipeline_paths())
        for line in result.log_lines:
            # first line already logged above with same text — skip exact duplicate
            if line.startswith("Парсинг DOCX ("):
                continue
            self._log(line)

        if not result.ok:
            if result.error_message and (
                not result.processed_files and result.errors
            ):
                messagebox.showerror(
                    "Помилка обробки",
                    result.error_message
                    or "Жоден DOCX не вдалося обробити. Деталі дивіться у журналі вкладки «Обробка».",
                )
            elif result.error_message:
                messagebox.showerror("Помилка обробки", result.error_message)
            self.status_var.set("Помилка")
            if result.combined_path:
                self.last_json = result.combined_path
            self.pb["value"] = 100
            self.update()
            return

        self.pb["value"] = 55
        self.update()
        self.last_json = result.combined_path
        self.status_var.set("Автозаповнення Excel...")
        self.pb["value"] = 90
        self.update()

        self.last_excel = result.excel_path
        self._refresh_results()
        self.refresh_people_view()
        self._refresh_quality_tree()
        self.pb["value"] = 100
        self.status_var.set("Готово ✅")

    # ---------- Results
    def _build_results(self):
        results_tab.build(self)

    def _refresh_results(self):
        self.res_excel.set(self.last_excel or "")
        self.res_json.set(self.last_json or "")
        self.res_diag.set(self.diag_path)

    def _open_last_excel(self):
        if self.last_excel and os.path.exists(self.last_excel):
            open_path(self.last_excel)
        else:
            messagebox.showinfo("Немає", "Ще не створено Excel.")

    def _open_last_json(self):
        if self.last_json and os.path.exists(self.last_json):
            open_path(self.last_json)
        else:
            messagebox.showinfo("Немає", "Ще не створено JSON.")

    def _open_diag(self):
        if os.path.exists(self.diag_path):
            open_path(self.diag_path)
        else:
            messagebox.showinfo("Немає", "Ще не створено діагностику.")

    def _autofill_from_combined(self):
        """Run Excel autofill using the current combined_v2.json (no DOCX re-parse)."""
        path = self.combined_path
        if not os.path.exists(path):
            messagebox.showwarning(
                "Немає JSON",
                f"Файл не знайдено:\n{path}\n\nСпочатку обробіть DOCX або оберіть JSON через «Автозаповнення Excel з JSON».",
            )
            return
        self._run_autofill_from_json_path(path)

    def _autofill_from_json_file(self):
        """Pick a JSON file and run Excel autofill from its records."""
        initial = self.parsed_dir if os.path.isdir(self.parsed_dir) else BASE_DIR
        path = filedialog.askopenfilename(
            title="Оберіть JSON з записами (combined_v2 / records)",
            initialdir=initial,
            filetypes=[
                ("JSON", "*.json"),
                ("Усі файли", "*.*"),
            ],
        )
        if not path:
            return
        self._run_autofill_from_json_path(path)

    def _run_autofill_from_json_path(self, json_path: str):
        """UI shell around pipeline_service.run_json_autofill (behaviour unchanged)."""
        if not os.path.exists(self.template_path):
            messagebox.showerror("Немає шаблону", f"Excel-шаблон не знайдено:\n{self.template_path}")
            return
        self.nb.select(self.tab_run)
        self.status_var.set("Автозаповнення Excel з JSON...")
        self.pb["value"] = 20
        self.update()

        result = run_json_autofill(json_path, self._pipeline_paths())
        for line in result.log_lines:
            self._log(line)

        if not result.ok:
            msg = result.error_message or "Помилка автозаповнення"
            low = msg.lower()
            if "не знайдено" in low or "not found" in low:
                messagebox.showerror("Файл не знайдено", msg)
            elif "запис" in low or "records" in low:
                messagebox.showwarning("Немає записів", msg)
            else:
                messagebox.showerror("Помилка автозаповнення", msg)
            self.status_var.set("Помилка")
            return

        self.last_excel = result.excel_path
        self.last_json = json_path
        self.pb["value"] = 100
        self.status_var.set("Готово ✅")
        self._refresh_results()
        messagebox.showinfo(
            "Автозаповнення готове",
            f"Записів: {result.records_count}\nExcel:\n{result.excel_path}",
        )

    # ---------- Parser quality / rules files
    def _build_quality_rules(self):
        """Manage JSON files that directly influence parser quality/accuracy."""
        quality_tab.build(self)

    def _quality_file_map(self):
        return dict(quality_ctl.QUALITY_FILE_MAP)

    def _quality_files_help_text(self):
        return quality_ctl.QUALITY_HELP_TEXT

    def _refresh_quality_tree(self):
        if not hasattr(self, "quality_tree"):
            return
        for iid in self.quality_tree.get_children():
            self.quality_tree.delete(iid)
        for name, dest, status in quality_ctl.list_quality_statuses(CONFIG):
            self.quality_tree.insert("", "end", values=(name, dest, status))

    def _validate_quality_file(self, path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if os.path.basename(path) == "military_order.schema.json":
            try:
                import jsonschema
                jsonschema.Draft7Validator.check_schema(data)
            except ImportError:
                return "JSON OK; jsonschema не встановлено"
        return "OK"

    def _validate_quality_jsons(self):
        errors = []
        ok = 0
        for name, rel in self._quality_file_map().items():
            path = os.path.join(CONFIG, rel)
            if not os.path.isfile(path):
                errors.append(f"{name}: файл відсутній")
                continue
            try:
                self._validate_quality_file(path)
                ok += 1
            except Exception as exc:
                errors.append(f"{name}: {exc}")
        self._refresh_quality_tree()
        if errors:
            messagebox.showerror("Перевірка JSON", f"Коректних: {ok}\nПомилок: {len(errors)}\n\n" + "\n".join(errors[:20]))
        else:
            messagebox.showinfo("Перевірка JSON", f"Усі {ok} активних JSON-файлів коректні.")

    def _import_quality_json(self):
        paths = filedialog.askopenfilenames(
            title="Виберіть JSON-файли правил парсера",
            filetypes=[("JSON", "*.json"), ("Усі файли", "*.*")]
        )
        if not paths:
            return

        fmap = self._quality_file_map()
        unknown = []
        planned = []
        for src in paths:
            name = os.path.basename(src)
            rel = fmap.get(name)
            if rel:
                planned.append((src, os.path.join(CONFIG, rel)))
            else:
                unknown.append(src)

        if unknown:
            unknown_dir = os.path.join(CONFIG, "quality_imports")
            os.makedirs(unknown_dir, exist_ok=True)
            for src in unknown:
                planned.append((src, os.path.join(unknown_dir, os.path.basename(src))))

        if not planned:
            return

        overwrite = [dst for _, dst in planned if os.path.exists(dst)]
        if overwrite:
            answer = messagebox.askyesno(
                "Підтвердження заміни",
                "Деякі активні JSON-файли вже існують. Перед заміною буде створено backup.\n\n"
                "Продовжити?"
            )
            if not answer:
                return

        import shutil
        backup_root = os.path.join(CONFIG, "backups", time.strftime("%Y%m%d_%H%M%S"))
        imported = []
        errors = []
        for src, dst in planned:
            try:
                self._validate_quality_file(src)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                if os.path.exists(dst):
                    rel = os.path.relpath(dst, CONFIG)
                    bdst = os.path.join(backup_root, rel)
                    os.makedirs(os.path.dirname(bdst), exist_ok=True)
                    shutil.copy2(dst, bdst)
                shutil.copy2(src, dst)
                imported.append(os.path.relpath(dst, CONFIG))
            except Exception as exc:
                errors.append(f"{os.path.basename(src)}: {exc}")

        self._refresh_quality_tree()
        try:
            self._cat_engine = None
            self._ensure_category_engine()
        except Exception:
            pass

        msg = f"Завантажено: {len(imported)}"
        if backup_root and overwrite:
            msg += f"\nBackup: {backup_root}"
        if errors:
            msg += "\n\nПомилки:\n" + "\n".join(errors)
            messagebox.showerror("Імпорт JSON", msg)
        else:
            messagebox.showinfo("Імпорт JSON", msg)

    def _export_quality_jsons(self):
        dst_dir = filedialog.askdirectory(title="Папка для експорту JSON-файлів правил")
        if not dst_dir:
            return
        count = quality_ctl.export_quality_files(CONFIG, dst_dir)
        messagebox.showinfo("Експорт JSON", f"Експортовано {count} файлів.")

    def build_people(self):
        people_tab.build(self)

    def _toggle_people_sidebar(self):
        """Collapse/expand the left sidebar in People tab."""
        try:
            pan = getattr(self, "_people_paned", None)
            left = getattr(self, "_people_left", None)
            if not pan or not left:
                return
            if not getattr(self, "_people_sidebar_collapsed", False):
                try:
                    pan.forget(left)
                except Exception:
                    return
                self._people_sidebar_collapsed = True
            else:
                try:
                    pan.insert(0, left, weight=1)
                except Exception:
                    return
                self._people_sidebar_collapsed = False
        except Exception:
            return

    def _toggle_person_wrap(self):
        if not hasattr(self, "person_text"):
            return
        try:
            cur = str(self.person_text.cget("wrap"))
            new_wrap = "none" if cur != "none" else "word"
            self.person_text.configure(wrap=new_wrap)
            self.ui_settings["wrap_person_text"] = (new_wrap != "none")
            self._save_ui_settings()
        except Exception:
            pass

    def _adjust_font_size(self, delta: int):
        try:
            cur = int((self.ui_settings.get("font") or {}).get("size") or 12)
            new_size = max(8, min(28, cur + int(delta)))
            self.ui_settings.setdefault("font", {})["size"] = new_size
            self._save_ui_settings()
            self._apply_global_style()
            # re-apply to existing text widgets
            for wname in ("person_text", "log", "unknown_units", "unknown_reasons", "unknown_arrivals"):
                w = getattr(self, wname, None)
                if w is not None:
                    self._apply_text_widget_style(w)
            self._reconfigure_people_text_tags()
        except Exception:
            pass

    def _reconfigure_people_text_tags(self):
        if not hasattr(self, "person_text"):
            return
        bold = ui_styles.reconfigure_people_text_tags(self.person_text, self.ui_settings)
        if bold is not None:
            self._font_bold = bold

    def open_person_original_view(self):
        """Open a separate window with the full raw blocks for the selected person."""
        pib = self._current_person_pib or self._get_selected_pib()
        if not pib:
            messagebox.showwarning("Немає людини", "Оберіть людину в списку.")
            return
        person = self._people_cache.get(pib) or {}
        mentions = person.get("mentions", []) or []

        def mention_key(m):
            dt = (m.get("date") or "").strip()
            dkey = self._parse_dt(dt) if dt else (9999, 12, 31)
            doc = (m.get("doc") or "").strip()
            bid = int(m.get("block_id") or 0)
            return (doc, dkey, bid)

        all_mentions = sorted(mentions, key=mention_key)

        win = tk.Toplevel(self)
        win.title(f"Оригінал — {pib}")
        win.geometry("980x700")

        outer = ttk.Frame(win, padding=10)
        outer.pack(fill="both", expand=True)

        topbar = ttk.Frame(outer)
        topbar.pack(fill="x")
        ttk.Label(topbar, text=f"ПІБ: {pib}").pack(side="left")
        ttk.Button(topbar, text="📄 Відкрити DOCX (якщо вибрано фрагмент)", command=self.open_selected_docx_source).pack(side="right")

        text_box = ttk.Frame(outer)
        text_box.pack(fill="both", expand=True, pady=(8, 0))
        wrap_mode = "word" if bool(self.ui_settings.get("wrap_person_text", True)) else "none"
        txt = tk.Text(text_box, wrap=wrap_mode)
        self._apply_text_widget_style(txt)
        ysb = ttk.Scrollbar(text_box, orient="vertical", command=txt.yview)
        xsb = ttk.Scrollbar(text_box, orient="horizontal", command=txt.xview)
        txt.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        txt.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        text_box.rowconfigure(0, weight=1)
        text_box.columnconfigure(0, weight=1)

        # fill content
        txt.insert("end", f"ПІБ: {pib}\n")
        txt.insert("end", "-" * 90 + "\n\n")
        for i, m in enumerate(all_mentions, start=1):
            doc = (m.get("doc") or "").strip() or "(невідомо)"
            bid = int(m.get("block_id") or 0)
            dt = (m.get("date") or "").strip() or "—"
            et = (m.get("event_type") or "").strip() or "—"
            text = (m.get("text") or "").strip()
            cat = m.get("_cat")
            if cat is None:
                # Prefer parser-provided category (if the parser already ran CategoryEngine).
                parsed_cat = m.get("category")
                if parsed_cat is not None:
                    cat = parsed_cat
                else:
                    c0, _, _ = self._classify_block_category(text, (m.get("event_type") or ""))
                    cat = c0
            head = f"[{i}] {dt} | {et} | {cat or '—'} | {doc} | блок {bid}\n"
            txt.insert("end", head)
            txt.insert("end", text + "\n\n")
        txt.configure(state="disabled")

    def _build_global_category_index(self) -> dict:
        """Category label stats from current people cache (Phase 6 helper)."""
        people = list(getattr(self, "_people_cache", {}).values())
        return people_ctl.build_global_category_index(people)

    def open_category_browser(self):
        """Browse blocks across people by the same category (arrival/departure)."""
        if not getattr(self, "_people_cache", None):
            self.refresh_people_view()
        idx = self._build_global_category_index()

        win = tk.Toplevel(self)
        win.title("Перегляд по категоріях")
        win.geometry("1100x700")

        outer = ttk.Frame(win, padding=10)
        outer.pack(fill="both", expand=True)

        pan = ttk.Panedwindow(outer, orient="horizontal")
        pan.pack(fill="both", expand=True)

        left = ttk.Frame(pan)
        right = ttk.Frame(pan)
        pan.add(left, weight=1)
        pan.add(right, weight=3)

        ttk.Label(left, text="Категорії:").pack(anchor="w")
        cat_tree_box = ttk.Frame(left)
        cat_tree_box.pack(fill="both", expand=True)
        cat_tree = ttk.Treeview(cat_tree_box, columns=("count",), show="tree headings", height=18)
        cat_tree.heading("#0", text="Категорія")
        cat_tree.heading("count", text="К-сть")
        cat_tree.column("#0", width=260)
        cat_tree.column("count", width=70, anchor="center")
        ysb = ttk.Scrollbar(cat_tree_box, orient="vertical", command=cat_tree.yview)
        xsb = ttk.Scrollbar(cat_tree_box, orient="horizontal", command=cat_tree.xview)
        cat_tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        cat_tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        cat_tree_box.rowconfigure(0, weight=1)
        cat_tree_box.columnconfigure(0, weight=1)

        # Right: fragments list
        topbar = ttk.Frame(right)
        topbar.pack(fill="x")
        ttk.Label(topbar, text="Фільтр:").pack(side="left")
        qv = tk.StringVar(value="")
        ent = ttk.Entry(topbar, textvariable=qv, width=40)
        ent.pack(side="left", padx=6)
        ttk.Label(topbar, text="(ПІБ/DOCX/текст)").pack(side="left")

        frag_box = ttk.Frame(right)
        frag_box.pack(fill="both", expand=True, pady=(8, 0))
        cols = ("pib", "date", "event", "category", "doc", "block", "snippet")
        frag_tree = ttk.Treeview(frag_box, columns=cols, show="headings", height=22)
        for col, title, w in [
            ("pib", "ПІБ", 220),
            ("date", "Дата", 90),
            ("event", "Подія", 80),
            ("category", "Категорія", 200),
            ("doc", "DOCX", 170),
            ("block", "Блок", 60),
            ("snippet", "Snippet", 520),
        ]:
            frag_tree.heading(col, text=title)
            frag_tree.column(col, width=w, anchor=("center" if col in ("block",) else "w"))
        ysb2 = ttk.Scrollbar(frag_box, orient="vertical", command=frag_tree.yview)
        xsb2 = ttk.Scrollbar(frag_box, orient="horizontal", command=frag_tree.xview)
        frag_tree.configure(yscrollcommand=ysb2.set, xscrollcommand=xsb2.set)
        frag_tree.grid(row=0, column=0, sticky="nsew")
        ysb2.grid(row=0, column=1, sticky="ns")
        xsb2.grid(row=1, column=0, sticky="ew")
        frag_box.rowconfigure(0, weight=1)
        frag_box.columnconfigure(0, weight=1)

        # meta map
        meta: dict[str, dict] = {}

        def _fill_cat_tree():
            cat_tree.delete(*cat_tree.get_children(""))
            for ev in ("arrival", "departure", "unknown"):
                total = sum(len(v) for v in idx.get(ev, {}).values())
                ev_iid = cat_tree.insert("", "end", text=ev, values=(total,))
                for cat in sorted(idx.get(ev, {}).keys(), key=lambda x: x.lower()):
                    cat_tree.insert(ev_iid, "end", text=cat, values=(len(idx[ev][cat]),))
                cat_tree.item(ev_iid, open=True)

        def _current_entries():
            sel = cat_tree.selection()
            if not sel:
                return []
            iid = sel[0]
            parent = cat_tree.parent(iid)
            if not parent:
                # event selected
                ev = cat_tree.item(iid, "text")
                out = []
                for cat in idx.get(ev, {}):
                    out.extend(idx[ev][cat])
                return out
            ev = cat_tree.item(parent, "text")
            cat = cat_tree.item(iid, "text")
            return list(idx.get(ev, {}).get(cat, []))

        def _apply_filter(entries: list[dict]):
            q = (qv.get() or "").strip().lower()
            if not q:
                return entries
            out = []
            for e in entries:
                blob = f"{e.get('pib','')} {e.get('doc','')} {e.get('snippet','')} {e.get('category','')}".lower()
                if q in blob:
                    out.append(e)
            return out

        def _refresh_frag_list(*_):
            frag_tree.delete(*frag_tree.get_children(""))
            meta.clear()
            entries = _apply_filter(_current_entries())
            for e in entries:
                iid = frag_tree.insert("", "end", values=(
                    e.get("pib"),
                    e.get("date") or "—",
                    e.get("event_type") or "—",
                    e.get("category") or "—",
                    e.get("doc") or "—",
                    e.get("block_id"),
                    e.get("snippet") or "",
                ))
                meta[iid] = e

        def _jump_to_entry(event=None):
            sel = frag_tree.selection()
            if not sel:
                return
            e = meta.get(sel[0]) or {}
            pib = e.get("pib")
            if not pib or pib not in self._people_cache:
                return
            # switch to people tab and show
            try:
                if hasattr(self, "nb"):
                    self.nb.select(self.tab_people)
            except Exception:
                pass
            self._current_person_pib = pib
            self._current_doc_filter = None
            self._current_event_filter = (e.get("event_type") or "").strip() if (e.get("event_type") or "").strip() in ("arrival", "departure") else None
            self._current_category_filter = e.get("category") if e.get("category") not in ("(без категорії)", None) else None
            self._render_person_into_ui(pib, self._people_cache[pib], doc_filter=self._current_doc_filter)
            # select matching fragment row
            target_doc = e.get("doc")
            target_bid = int(e.get("block_id") or 0)
            for iid2, m in (self._frag_meta or {}).items():
                if (m.get("doc") == target_doc) and int(m.get("block_id") or 0) == target_bid:
                    try:
                        self.frag_tree.selection_set(iid2)
                        self.frag_tree.focus(iid2)
                        self.jump_to_selected_fragment()
                    except Exception:
                        pass
                    break

        _fill_cat_tree()
        cat_tree.bind("<<TreeviewSelect>>", _refresh_frag_list)
        ent.bind("<KeyRelease>", _refresh_frag_list)
        frag_tree.bind("<Double-1>", _jump_to_entry)
        # select first event
        roots = cat_tree.get_children("")
        if roots:
            cat_tree.selection_set(roots[0])
            _refresh_frag_list()

    def open_user_category_rules_manager(self):
        """Allow enabling/disabling/deleting user rules created from selection."""
        os.makedirs(os.path.dirname(self.user_category_rules_path), exist_ok=True)
        if not os.path.exists(self.user_category_rules_path):
            with open(self.user_category_rules_path, "w", encoding="utf-8") as f:
                json.dump({"rules": []}, f, ensure_ascii=False, indent=2)

        def load_rules():
            try:
                with open(self.user_category_rules_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                rules = data.get("rules") or []
                return [r for r in rules if isinstance(r, dict)]
            except Exception:
                return []

        def save_rules(rules: list[dict]):
            with open(self.user_category_rules_path, "w", encoding="utf-8") as f:
                json.dump({"rules": rules}, f, ensure_ascii=False, indent=2)

        win = tk.Toplevel(self)
        win.title("User правила категорій")
        win.geometry("1050x550")

        outer = ttk.Frame(win, padding=10)
        outer.pack(fill="both", expand=True)

        topbar = ttk.Frame(outer)
        topbar.pack(fill="x")
        ttk.Label(topbar, text="Фільтр:").pack(side="left")
        qv = tk.StringVar(value="")
        qent = ttk.Entry(topbar, textvariable=qv, width=40)
        qent.pack(side="left", padx=6)

        box = ttk.Frame(outer)
        box.pack(fill="both", expand=True, pady=(8, 0))

        cols = ("enabled", "event", "label", "regex", "priority", "id")
        tree = ttk.Treeview(box, columns=cols, show="headings", height=18)
        for c, t, w in [
            ("enabled", "ON", 55),
            ("event", "Подія", 80),
            ("label", "Категорія", 200),
            ("regex", "Regex", 420),
            ("priority", "Priority", 70),
            ("id", "ID", 180),
        ]:
            tree.heading(c, text=t)
            tree.column(c, width=w, anchor=("center" if c in ("enabled", "priority") else "w"))
        ysb = ttk.Scrollbar(box, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(box, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(8, 0))
        ttk.Button(btns, text="✅/🚫 Увімкнути/вимкнути", command=lambda: toggle()).pack(side="left")
        ttk.Button(btns, text="🗑 Видалити", command=lambda: delete()).pack(side="left", padx=6)
        ttk.Button(btns, text="📂 Відкрити JSON", command=lambda: open_path(self.user_category_rules_path)).pack(side="right")

        rules = load_rules()
        meta: dict[str, dict] = {}

        def norm_rx(r):
            m = r.get("match") or {}
            any_ = m.get("any") or []
            return str(any_[0]) if any_ else ""

        def refresh():
            tree.delete(*tree.get_children(""))
            meta.clear()
            q = (qv.get() or "").strip().lower()
            for r in rules:
                rid = r.get("id") or ""
                ev = r.get("event_type") or ""
                lbl = r.get("label") or ""
                rx = norm_rx(r)
                pr = int(r.get("priority") or 0)
                en = bool(r.get("enabled", True))
                blob = f"{ev} {lbl} {rx} {rid}".lower()
                if q and q not in blob:
                    continue
                iid = tree.insert("", "end", values=("ON" if en else "OFF", ev, lbl, rx, pr, rid))
                meta[iid] = r

        def toggle():
            sel = tree.selection()
            if not sel:
                return
            r = meta.get(sel[0])
            if not r:
                return
            r["enabled"] = not bool(r.get("enabled", True))
            save_rules(rules)
            self._ensure_category_engine()
            refresh()
            # keep UI consistent
            if self._current_person_pib and self._current_person_pib in self._people_cache:
                self._render_person_into_ui(self._current_person_pib, self._people_cache[self._current_person_pib], doc_filter=self._current_doc_filter)

        def delete():
            sel = tree.selection()
            if not sel:
                return
            r = meta.get(sel[0])
            if not r:
                return
            rid = r.get("id")
            if not rid:
                return
            # remove
            rules[:] = [x for x in rules if x.get("id") != rid]
            save_rules(rules)
            self._ensure_category_engine()
            refresh()
            if self._current_person_pib and self._current_person_pib in self._people_cache:
                self._render_person_into_ui(self._current_person_pib, self._people_cache[self._current_person_pib], doc_filter=self._current_doc_filter)

        qent.bind("<KeyRelease>", lambda e: refresh())
        refresh()



    def _ensure_category_engine(self):
        """Load category rules engine if possible. Never crash UI if rules are missing."""
        try:
            if os.path.exists(self.category_rules_path):
                self._cat_engine = CategoryEngine(self.category_rules_path, self.user_category_rules_path)
            else:
                self._cat_engine = None
        except Exception:
            self._cat_engine = None

    def _add_rule_from_selection(self):
        """Create a new category rule from the currently selected phrase in person_text."""
        if not hasattr(self, "person_text"):
            return
        try:
            phrase = self.person_text.get(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            messagebox.showwarning("Нема виділення", "Виділіть у тексті слово/фразу, а потім натисніть 'Правило з виділення'.")
            return
        phrase = (phrase or "").strip()
        if not phrase:
            messagebox.showwarning("Нема виділення", "Виділіть у тексті слово/фразу (не порожньо).")
            return

        default_event = "arrival"
        sel = self.frag_tree.selection() if hasattr(self, "frag_tree") else ()
        if sel:
            meta = self._frag_meta.get(sel[0]) or {}
            et = (meta.get("event_type") or "").strip()
            if et in ("arrival", "departure"):
                default_event = et

        self._open_rule_dialog(phrase, default_event)

    def _open_rule_dialog(self, phrase: str, default_event: str):
        """Modal dialog to create rule from phrase (UI in gui.dialogs)."""
        if self._cat_engine is None:
            self._ensure_category_engine()
        open_rule_from_selection_dialog(
            self,
            phrase=phrase,
            default_event=default_event,
            cat_engine=self._cat_engine,
            make_regex_from_phrase=make_regex_from_phrase,
            on_persist=self._persist_category_rule,
        )

    def _persist_category_rule(self, event_type: str, label: str, regex: str, priority_high: bool = True):
        """Write a new rule into user_category_rules.json (and reload)."""
        # ensure user rules file exists
        if not os.path.exists(self.user_category_rules_path):
            with open(self.user_category_rules_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "rules": []}, f, ensure_ascii=False, indent=2)

        with open(self.user_category_rules_path, "r", encoding="utf-8") as f:
            udata = json.load(f) if f.readable() else {"version": 1, "rules": []}
        if not isinstance(udata, dict):
            udata = {"version": 1, "rules": []}
        udata.setdefault("version", 1)
        udata.setdefault("rules", [])
        if not isinstance(udata["rules"], list):
            udata["rules"] = []

        # stable-ish id
        base = f"{event_type}:{label}:{regex}".encode("utf-8")
        hid = hashlib.sha256(base).hexdigest()[:8]
        slug = re.sub(r"[^a-z0-9_]+", "_", label.lower())
        rid = f"{'arr' if event_type=='arrival' else 'dep'}_{slug}_{hid}"

        rule = {
            "id": rid,
            "event_type": event_type,
            "label": label,
            "match": {"any": [regex]},
            "priority": "high" if priority_high else "low",
            "enabled": True,
        }

        # de-dup by id (or same label+regex+event)
        def _same(r: dict) -> bool:
            try:
                return (r.get("id") == rid) or (
                    (r.get("event_type") == event_type)
                    and (r.get("label") == label)
                    and (r.get("match") or {}).get("any") == [regex]
                )
            except Exception:
                return False
        udata["rules"] = [r for r in udata["rules"] if not _same(r)]

        # prepend high priority rules
        if priority_high:
            udata["rules"].insert(0, rule)
        else:
            udata["rules"].append(rule)

        with open(self.user_category_rules_path, "w", encoding="utf-8") as f:
            json.dump(udata, f, ensure_ascii=False, indent=2)

        self._ensure_category_engine()

        # refresh current person view
        pib = self._current_person_pib
        if pib and pib in self._people_cache:
            self._render_person_into_ui(pib, self._people_cache[pib], doc_filter=self._current_doc_filter)

    def _person_text_context_menu(self, event):
        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Копіювати", command=lambda: self.person_text.event_generate("<<Copy>>"))
        menu.add_separator()
        menu.add_command(label="➕ Правило з виділення", command=self._add_rule_from_selection)
        menu.add_command(label="🔧 Ручний розбір полів", command=self._manual_field_parse)
        menu.tk_popup(event.x_root, event.y_root)


    def refresh_people_view(self):
        # Load combined_v2.json and build alphabetical index by PIB
        self._people_cache = {}
        self._people_all_pibs = []
        self._people_filtered_pibs = []
        # clear UI lists
        if hasattr(self, "people_tree"):
            for iid in self.people_tree.get_children():
                self.people_tree.delete(iid)
        if hasattr(self, "docs_tree"):
            for iid in self.docs_tree.get_children():
                self.docs_tree.delete(iid)
        if hasattr(self, "frag_tree"):
            for iid in self.frag_tree.get_children():
                self.frag_tree.delete(iid)
        self._frag_meta = {}
        self._docs_meta = {}
        self._mention_pos = {}
        if not os.path.exists(self.combined_path):
            self.person_text.delete("1.0", "end")
            self.person_text.insert("end", "Немає combined_v2.json. Спочатку обробіть DOCX.\n")

            return
        try:
            with open(self.combined_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            self.person_text.delete("1.0", "end")
            self.person_text.insert("end", f"Не можу прочитати combined_v2.json: {e}\n")
            return

        people = data.get("people", []) if isinstance(data, dict) else []
        people_sorted = sorted(people, key=lambda p: (p.get("pib") or "").upper())

        for p in people_sorted:
            pib = (p.get("pib") or "").strip()
            if not pib:
                continue
            self._people_cache[pib] = p
            self._people_all_pibs.append(pib)

        self.apply_people_filter(select_first=True)

    def apply_people_filter(self, select_first=False):
        # Filter people by substring (case-insensitive) and keep alphabetical order
        q = (self.people_filter.get() if hasattr(self, "people_filter") else "").strip().upper()
        if not q:
            self._people_filtered_pibs = list(self._people_all_pibs)
        else:
            self._people_filtered_pibs = [p for p in self._people_all_pibs if q in p.upper()]
        # ignore hidden people
        try:
            hidden = getattr(self, "_ignored_people", set()) or set()
            if hidden:
                self._people_filtered_pibs = [p for p in self._people_filtered_pibs if p not in hidden]
        except Exception:
            pass

        # rebuild tree
        if hasattr(self, "people_tree"):
            for iid in self.people_tree.get_children():
                self.people_tree.delete(iid)
            for pib in self._people_filtered_pibs:
                p = self._people_cache.get(pib) or {}
                blocks = len(p.get("mentions") or [])
                records = len(p.get("records") or [])
                # Tag PІБ row by event types present for this person
                has_arrival = False
                has_departure = False
                for mm in (p.get("mentions") or []):
                    et0 = (mm.get("event_type") or "").strip().lower()
                    if et0 == "arrival":
                        has_arrival = True
                    elif et0 == "departure":
                        has_departure = True
                    if has_arrival and has_departure:
                        break
                if has_arrival and has_departure:
                    tags = ("BOTH",)
                elif has_arrival:
                    tags = ("ARRIVAL",)
                elif has_departure:
                    tags = ("DEPARTURE",)
                else:
                    tags = ()
                self.people_tree.insert("", "end", values=(pib, blocks, records), tags=tags)

        if select_first and self._people_filtered_pibs and hasattr(self, "people_tree"):
            first = self.people_tree.get_children()[0]
            self.people_tree.selection_set(first)
            self.people_tree.focus(first)
            self.show_selected_person()
        elif not self._people_filtered_pibs:
            self.person_text.delete("1.0", "end")
            self.person_text.insert("end", "Немає збігів.\n")


    def _parse_dt(self, s):
        return people_ctl.parse_dt_key(s)

    def _get_selected_pib(self):
        if not hasattr(self, "people_tree"):
            return None
        sel = self.people_tree.selection()
        if not sel:
            return None
        vals = self.people_tree.item(sel[0], "values")
        if not vals:
            return None
        return vals[0]

    def _resolve_docx_path(self, doc_name: str):
        """Try to locate the DOCX by name under current input selection and default docs dir."""
        if not doc_name:
            return None
        if doc_name in self._docx_by_name_cache and os.path.exists(self._docx_by_name_cache[doc_name]):
            return self._docx_by_name_cache[doc_name]

        # candidate roots
        roots = []
        sel = (self.selected_path.get() or "").strip()
        if sel:
            if os.path.isdir(sel):
                roots.append(sel)
            elif os.path.isfile(sel):
                roots.append(os.path.dirname(sel))
        roots.append(DOCS_DIR)

        target = doc_name.lower()
        for root in roots:
            if not os.path.isdir(root):
                continue
            for r, _, fs in os.walk(root):
                for f in fs:
                    if f.lower() == target:
                        full = os.path.join(r, f)
                        self._docx_by_name_cache[doc_name] = full
                        return full
        return None

    def open_selected_docx_source(self):
        """Open DOCX source for selected fragment or selected doc in the left panel."""
        doc_name = None
        # prefer fragment selection
        if hasattr(self, "frag_tree"):
            sel = self.frag_tree.selection()
            if sel and sel[0] in self._frag_meta:
                doc_name = self._frag_meta[sel[0]].get("doc")
        # else doc panel selection
        if not doc_name and hasattr(self, "docs_tree"):
            dsel = self.docs_tree.selection()
            if dsel:
                meta = (self._docs_meta.get(dsel[0]) or {}) if hasattr(self, "_docs_meta") else {}
                if meta.get("type") in ("doc", "block"):
                    doc_name = meta.get("doc")
        # else current filter
        if not doc_name:
            doc_name = self._current_doc_filter

        if not doc_name:
            messagebox.showwarning("Немає документа", "Оберіть фрагмент або документ.")
            return
        path = self._resolve_docx_path(doc_name)
        if not path:
            messagebox.showwarning("Не знайдено", f"Не можу знайти файл: {doc_name}\n\nСпробуйте покласти його у input/documents або оберіть папку у вкладці 'Вхід'.")
            return
        open_path(path)

    def _event_match_regex(self, event_type: str):
        et = (event_type or "").strip().lower()
        if et == "arrival":
            return re.compile(r"(прибув\w*|прибут\w*|зарахув\w*|призван\w*|направлен\w*)", re.IGNORECASE)
        if et == "departure":
            return re.compile(
                r"(звільн\w*|виведен\w*|переведен\w*|виключ\w*|загиб\w*|помер\w*|призупинен\w*|полон\w*|сзч)",
                re.IGNORECASE,
            )
        return re.compile(r"(звільн\w*|прибув\w*|виведен\w*|зарахув\w*)", re.IGNORECASE)

    def _select_fragment_row(self, doc: str, block_id: int):
        if not hasattr(self, "frag_tree"):
            return
        for iid, meta in (self._frag_meta or {}).items():
            if meta.get("doc") == doc and int(meta.get("block_id") or 0) == int(block_id):
                self.frag_tree.selection_set(iid)
                self.frag_tree.focus(iid)
                self.frag_tree.see(iid)
                return

    def _on_docs_tree_select(self):
        """Docs panel behavior:

        - select '(усі)'  -> clear doc filter
        - select doc node -> set filter to this doc
        - select block node -> ensure filter doc + jump to block
        """
        if not hasattr(self, "docs_tree"):
            return
        sel = self.docs_tree.selection()
        if not sel:
            return
        meta = (self._docs_meta or {}).get(sel[0]) or {}
        t = meta.get("type")
        pib = self._current_person_pib
        person = self._people_cache.get(pib) if pib else None
        if not person:
            return

        if t == "all":
            if self._current_doc_filter is None:
                return
            self._current_doc_filter = None
            self._render_person_into_ui(pib, person, doc_filter=None)
            return

        if t == "doc":
            doc = meta.get("doc")
            if not doc:
                return
            if self._current_doc_filter == doc:
                return
            self._current_doc_filter = doc
            self._render_person_into_ui(pib, person, doc_filter=doc)
            return

        if t == "block":
            doc = meta.get("doc")
            bid = meta.get("block_id")
            if not doc or bid is None:
                return
            bid = int(bid)
            if self._current_doc_filter != doc:
                self._current_doc_filter = doc
                self._render_person_into_ui(pib, person, doc_filter=doc)
            self._select_fragment_row(doc, bid)
            self.jump_to_selected_fragment()

    def _on_docs_tree_open_or_jump(self):
        """Double click: open the underlying DOCX (and keep selection logic)."""
        if not hasattr(self, "docs_tree"):
            return
        sel = self.docs_tree.selection()
        if not sel:
            return
        meta = (self._docs_meta or {}).get(sel[0]) or {}
        if meta.get("type") in ("doc", "block"):
            doc_name = meta.get("doc")
            if doc_name:
                path = self._resolve_docx_path(doc_name)
                if path:
                    open_path(path)

    def find_in_person_text(self, next_: bool = True):
        q = (self.find_var.get() if hasattr(self, "find_var") else "").strip()
        if not q:
            return
        self.person_text.tag_remove("FIND", "1.0", "end")

        # start search from insert mark
        start = self.person_text.index(tk.INSERT)
        if next_:
            pos = self.person_text.search(q, start, nocase=1, stopindex="end")
            if not pos:
                pos = self.person_text.search(q, "1.0", nocase=1, stopindex="end")
        else:
            pos = self.person_text.search(q, start, nocase=1, stopindex="1.0", backwards=True)
            if not pos:
                pos = self.person_text.search(q, "end", nocase=1, stopindex="1.0", backwards=True)

        if not pos:
            return
        end = f"{pos}+{len(q)}c"
        self.person_text.tag_add("FIND", pos, end)
        self.person_text.mark_set(tk.INSERT, end)
        self.person_text.see(pos)

    def clear_find_highlight(self):
        self.person_text.tag_remove("FIND", "1.0", "end")

    def jump_to_selected_fragment(self):
        if not hasattr(self, "frag_tree"):
            return
        sel = self.frag_tree.selection()
        if not sel:
            return
        meta = self._frag_meta.get(sel[0]) or {}
        doc = meta.get("doc")
        bid = meta.get("block_id")
        if not doc or bid is None:
            return
        key = (doc, int(bid))
        pos = self._mention_pos.get(key)
        if not pos:
            return

        # clear previous highlights
        self.person_text.tag_remove("BLOCK_ACTIVE", "1.0", "end")
        self.person_text.tag_remove("MATCH_ACTIVE", "1.0", "end")
        self.person_text.tag_remove("PIB_MATCH", "1.0", "end")
        self.person_text.tag_remove("CAT_MATCH", "1.0", "end")

        self.person_text.tag_add("BLOCK_ACTIVE", pos["block_start"], pos["block_end"])
        self.person_text.see(pos["block_start"])
        self.person_text.mark_set(tk.INSERT, pos["block_start"])

        raw = meta.get("text") or ""
        rx = self._event_match_regex(meta.get("event_type") or "")
        m = rx.search(raw)
        if m:
            s_off, e_off = m.span()
            s_idx = f"{pos['content_start']}+{s_off}c"
            e_idx = f"{pos['content_start']}+{e_off}c"
            self.person_text.tag_add("MATCH_ACTIVE", s_idx, e_idx)
            self.person_text.see(s_idx)

        # Highlight the person's PIB itself (first match in the block)
        pib = self._current_person_pib or ""
        pib = pib.strip()
        if pib:
            try:
                pm = re.search(re.escape(pib), raw, flags=re.IGNORECASE)
            except re.error:
                pm = None
            if pm:
                ps, pe = pm.span()
                ps_idx = f"{pos['content_start']}+{ps}c"
                pe_idx = f"{pos['content_start']}+{pe}c"
                self.person_text.tag_add("PIB_MATCH", ps_idx, pe_idx)

        # Highlight category match span (rule-based)
        cat_span = meta.get("cat_span")
        if cat_span and isinstance(cat_span, (list, tuple)) and len(cat_span) == 2:
            try:
                cs, ce = int(cat_span[0]), int(cat_span[1])
            except Exception:
                cs, ce = None, None
            if cs is not None and ce is not None and ce > cs:
                cs_idx = f"{pos['content_start']}+{cs}c"
                ce_idx = f"{pos['content_start']}+{ce}c"
                self.person_text.tag_add("CAT_MATCH", cs_idx, ce_idx)
                self.person_text.see(cs_idx)


    def _classify_block_category(self, block_text: str, event_type: str):
        """Return (category_label, rule_id, span_tuple) for a block."""
        if not self._cat_engine:
            return (None, None, None)
        try:
            res = self._cat_engine.classify(block_text or "", event_hint=event_type)
            return (res.get("category"), res.get("rule_id"), res.get("match_span"))
        except Exception:
            return (None, None, None)
    def _render_person_into_ui(self, pib: str, person: dict, doc_filter: str | None = None):
        """Render per-person view: docs list, fragments list and full block text.

        - docs_tree: shows DOCX -> count of blocks
        - frag_tree: shows one row per block (variant A)
        - person_text: prints full blocks, keeps index mapping for jump/highlight
        """

        mentions = person.get("mentions", []) or []
        ranks = person.get("ranks", []) or []
        variants = person.get("variants", []) or []

        def mention_key(m):
            dt = (m.get("date") or "").strip()
            dkey = self._parse_dt(dt) if dt else (9999, 12, 31)
            doc = (m.get("doc") or "").strip()
            bid = int(m.get("block_id") or 0)
            return (doc, dkey, bid)

        all_mentions = sorted(mentions, key=mention_key)

        # Precompute categories for mentions (cache into dict)
        # Prefer parser-provided category fields if present (stable spans for highlight).
        for _m in all_mentions:
            if _m.get("_cat") is None and "_cat" in _m:
                continue

            has_parsed = any(k in _m for k in ("category", "rule_id", "cat_span"))
            parsed_cat = _m.get("category")
            parsed_span = _m.get("cat_span")
            parsed_rule = _m.get("rule_id")

            if has_parsed and (parsed_cat is not None or parsed_span is not None or parsed_rule is not None):
                _m["_cat"] = parsed_cat
                _m["_cat_rule"] = parsed_rule
                _m["_cat_span"] = parsed_span
                continue

            txt = (_m.get("text") or "").strip()
            et0 = (_m.get("event_type") or "").strip()
            cat0, rule0, span0 = self._classify_block_category(txt, et0)
            _m["_cat"] = cat0
            _m["_cat_rule"] = rule0
            _m["_cat_span"] = span0

        base_mentions = all_mentions
        # Apply event/category filters from category tree
        if self._current_event_filter in ("arrival", "departure"):
            base_mentions = [m for m in base_mentions if (m.get("event_type") or "").strip() == self._current_event_filter]
        if self._current_category_filter:
            base_mentions = [m for m in base_mentions if (m.get("_cat") or "") == self._current_category_filter]
        filtered_mentions = [m for m in base_mentions if (m.get("doc") or "") == doc_filter] if doc_filter else base_mentions

        # ---- docs panel (DOCX -> blocks)
        self._docs_meta = {}
        if hasattr(self, "docs_tree"):
            for iid in self.docs_tree.get_children():
                self.docs_tree.delete(iid)

            # Count blocks per doc
            counts: dict[str, int] = {}
            per_doc: dict[str, list[dict]] = {}
            for m in all_mentions:
                d = (m.get("doc") or "").strip() or "(невідомо)"
                counts[d] = counts.get(d, 0) + 1
                per_doc.setdefault(d, []).append(m)

            total = sum(counts.values())
            all_iid = self.docs_tree.insert("", "end", text="(усі)", values=(total,))
            self._docs_meta[all_iid] = {"type": "all"}

            for d in sorted(per_doc.keys(), key=lambda x: x.lower()):
                doc_iid = self.docs_tree.insert("", "end", text=d, values=(counts.get(d, 0),))
                self._docs_meta[doc_iid] = {"type": "doc", "doc": d}
                # Add blocks as children
                for m in sorted(per_doc[d], key=mention_key):
                    bid = int(m.get("block_id") or 0)
                    dt = (m.get("date") or "").strip()
                    et = (m.get("event_type") or "").strip()
                    cat, cat_rule, cat_span = m.get("_cat"), m.get("_cat_rule"), m.get("_cat_span")
                    lbl = f"{dt or '—'} | {et or '—'} | {cat or '—'} | блок {bid}"
                    child = self.docs_tree.insert(doc_iid, "end", text=lbl, values=("",), tags=_ui_tag_for_event_and_category(et, cat))
                    self._docs_meta[child] = {
                        "type": "block",
                        "doc": d,
                        "block_id": bid,
                        "date": dt,
                        "event_type": et,
                        "text": (m.get("text") or "").strip(),
                    }

            # Select current filter doc if set
            if doc_filter:
                for iid in self.docs_tree.get_children(""):
                    meta = self._docs_meta.get(iid) or {}
                    if meta.get("type") == "doc" and meta.get("doc") == doc_filter:
                        self.docs_tree.selection_set(iid)
                        self.docs_tree.focus(iid)
                        self.docs_tree.item(iid, open=True)
                        break

        # ---- fragments table
        if hasattr(self, "frag_tree"):
            for iid in self.frag_tree.get_children():
                self.frag_tree.delete(iid)
        self._frag_meta = {}

        for idx, m in enumerate(filtered_mentions, start=1):
            doc = (m.get("doc") or "").strip()
            bid = int(m.get("block_id") or 0)
            dt = (m.get("date") or "").strip()
            et = (m.get("event_type") or "").strip()
            text = (m.get("text") or "").strip()
            cat, cat_rule, cat_span = m.get("_cat"), m.get("_cat_rule"), m.get("_cat_span")

            snippet = " ".join(text.split())
            if len(snippet) > 220:
                snippet = snippet[:217] + "..."
            iid = self.frag_tree.insert("", "end", values=(idx, dt, et, cat, doc, bid, snippet), tags=_ui_tag_for_event_and_category(et, cat))
            self._frag_meta[iid] = {
                "doc": doc,
                "block_id": bid,
                "date": dt,
                "event_type": et,
                "text": text,
                "category": cat,
                "cat_rule_id": cat_rule,
                "cat_span": cat_span,
            }

        # ---- text area
        self.person_text.tag_remove("BLOCK_ACTIVE", "1.0", "end")
        self.person_text.tag_remove("MATCH_ACTIVE", "1.0", "end")
        self.clear_find_highlight()

        self.person_text.configure(state="normal")
        self.person_text.delete("1.0", "end")
        self._mention_pos = {}

        # Header
        self.person_text.insert("end", f"ПІБ: {pib}\n", "HDR")
        if ranks:
            self.person_text.insert("end", f"Звання: {', '.join(ranks)}\n")
        if variants:
            self.person_text.insert("end", "Варіанти: " + "; ".join([str(v) for v in variants if v]) + "\n")
        if doc_filter:
            self.person_text.insert("end", f"Фільтр документа: {doc_filter}\n")
        self.person_text.insert("end", "-" * 88 + "\n")

        if not filtered_mentions:
            self.person_text.insert("end", "Немає блоків для показу (перевірте фільтр).\n")
            return

        for idx, m in enumerate(filtered_mentions, start=1):
            doc = (m.get("doc") or "").strip()
            bid = int(m.get("block_id") or 0)
            dt = (m.get("date") or "").strip()
            et = (m.get("event_type") or "").strip()
            sec = m.get("section_path") or []
            sec_s = " → ".join([s for s in sec if s])
            text = (m.get("text") or "").strip()

            block_start = self.person_text.index("end-1c")
            cat, cat_rule, cat_span = m.get("_cat"), m.get("_cat_rule"), m.get("_cat_span")
            header = f"[{idx}] {dt or '—'} | {et or '—'} | {cat or '—'} | {doc} | блок {bid}\n"
            self.person_text.insert("end", header, ("HDR",) + _ui_tag_for_event_and_category(et, cat))
            if sec_s:
                self.person_text.insert("end", f"  Контекст: {sec_s}\n")

            content_start = self.person_text.index("end-1c")
            self.person_text.insert("end", text + "\n\n")
            block_end = self.person_text.index("end-1c")
            content_end = f"{content_start}+{len(text)}c"
            self._mention_pos[(doc, bid)] = {
                "block_start": block_start,
                "block_end": block_end,
                "content_start": content_start,
                "content_end": content_end,
            }


    def _clear_category_filter(self):
        if self._current_person_pib and self._current_person_pib in self._people_cache:
            self._current_event_filter = None
            self._current_category_filter = None
            self._render_person_into_ui(self._current_person_pib, self._people_cache[self._current_person_pib], doc_filter=self._current_doc_filter)

    def _on_cats_tree_select(self):
        if not hasattr(self, "cats_tree"):
            return
        sel = self.cats_tree.selection()
        if not sel:
            return
        meta = (self._cats_meta or {}).get(sel[0]) or {}
        pib = self._current_person_pib
        person = self._people_cache.get(pib) if pib else None
        if not person:
            return

        if meta.get("type") == "all":
            self._current_event_filter = None
            self._current_category_filter = None
        elif meta.get("type") == "event":
            self._current_event_filter = meta.get("event")
            self._current_category_filter = None
        elif meta.get("type") == "cat":
            self._current_event_filter = meta.get("event")
            self._current_category_filter = meta.get("label")

        self._render_person_into_ui(pib, person, doc_filter=self._current_doc_filter)

    def show_selected_person(self):
        pib = self._get_selected_pib()
        if not pib:
            return
        person = self._people_cache.get(pib)
        if not person:
            return

        self._current_person_pib = pib
        self._current_doc_filter = None
        self._current_event_filter = None
        self._current_category_filter = None
        self._render_person_into_ui(pib, person, doc_filter=None)

    def export_person_txt(self):
        pib = self._get_selected_pib()
        if not pib:
            messagebox.showwarning("Нема вибору", "Оберіть людину зі списку.")
            return
        safe = "".join([c for c in pib if c.isalnum() or c in " _-"]).strip().replace(" ", "_")
        path = os.path.join(self.exports_txt_dir, f"{safe}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.person_text.get("1.0", "end").strip() + "\n")
        messagebox.showinfo("Збережено", f"TXT: {path}")

    def export_person_json(self):
        pib = self._get_selected_pib()
        if not pib:
            messagebox.showwarning("Нема вибору", "Оберіть людину зі списку.")
            return
        person = self._people_cache.get(pib)
        if not person:
            return
        safe = "".join([c for c in pib if c.isalnum() or c in " _-"]).strip().replace(" ", "_")
        path = os.path.join(self.exports_json_dir, f"{safe}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(person, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Збережено", f"JSON: {path}")


    def export_all_people_zip(self):
        # Export all people to TXT+JSON and pack into one ZIP
        if not os.path.exists(self.combined_path):
            messagebox.showwarning("Немає даних", "Спочатку обробіть DOCX, щоб зʼявився combined_v2.json.")
            return
        if not self._people_cache:
            self.refresh_people_view()
        if not self._people_cache:
            messagebox.showwarning("Немає даних", "Список людей порожній.")
            return

        ts = time.strftime("%Y%m%d_%H%M%S")
        out_dir = os.path.join(OUTPUT, "exports", "people_all")
        os.makedirs(out_dir, exist_ok=True)
        zip_path = os.path.join(out_dir, f"people_all_{ts}.zip")

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for pib, person in sorted(self._people_cache.items(), key=lambda kv: kv[0].upper()):
                safe = "".join([c for c in pib if c.isalnum() or c in " _-"]).strip().replace(" ", "_")
                z.writestr(f"json/{safe}.json", json.dumps(person, ensure_ascii=False, indent=2))
                txt = self._render_person_text(pib, person)
                z.writestr(f"txt/{safe}.txt", txt + "\n")

        messagebox.showinfo("Готово", f"ZIP експортовано:\n{zip_path}")
        open_path(out_dir)

    def _render_person_text(self, pib, person):
        variants = person.get("variants", [])
        ranks = person.get("ranks", [])
        records = person.get("records", [])
        mentions = person.get("mentions", [])

        def rec_key(r):
            dt = r.get("arrival_date") or r.get("departure_date") or ""
            dkey = self._parse_dt(dt) if dt else (9999, 12, 31)
            order = (r.get("order_number") or "")
            et = (r.get("event_type") or "")
            return (dkey, order, et)

        records_sorted = sorted(records, key=rec_key)

        # Mentions: keep full block text and show it as "пункти наказу"
        def mention_key(m):
            dt = (m.get("date") or "")
            dkey = self._parse_dt(dt) if dt else (9999, 12, 31)
            doc = (m.get("doc") or "")
            bid = int(m.get("block_id") or 0)
            return (doc, dkey, bid)

        mentions_sorted = sorted(mentions, key=mention_key)

        out = []
        out.append(f"ПІБ: {pib}")
        if ranks:
            out.append(f"Звання: {', '.join(ranks)}")
        if variants:
            out.append("Варіанти написання: " + "; ".join([str(v) for v in variants if v]))
        if mentions_sorted:
            out.append(f"Знайдено пунктів/блоків у наказах: {len(mentions_sorted)}")
        out.append("-" * 70)

        if mentions_sorted:
            # Full structured view (preferred)
            for idx, m in enumerate(mentions_sorted, start=1):
                doc = (m.get("doc") or "").strip()
                bid = m.get("block_id")
                et = (m.get("event_type") or "").strip()
                dt = (m.get("date") or "").strip()
                sec = m.get("section_path") or []
                sec_s = " → ".join([s for s in sec if s])
                text = (m.get("text") or "").strip()

                header = [f"Пункт {idx}"]
                if doc:
                    header.append(f"Документ: {doc}")
                if bid:
                    header.append(f"Блок: {bid}")
                if dt:
                    header.append(f"Дата: {dt}")
                if et:
                    header.append(f"Подія: {et}")
                out.append(" | ".join(header))
                if sec_s:
                    out.append(f"  Контекст: {sec_s}")
                if text:
                    out.append("  Текст (повністю):")
                    # indent block lines
                    for ln in text.splitlines():
                        out.append("    " + ln)
                out.append("")

        else:
            # Fallback: show records (legacy)
            for r in records_sorted:
                et = (r.get("event_type") or "").strip()
                date = r.get("arrival_date") or r.get("departure_date") or ""
                pos = r.get("position") or ""
                frm = r.get("from_unit") or ""
                to = r.get("to_unit") or ""
                reason = r.get("departure_reason") or ""
                src = r.get("arrival_source") or ""
                order = r.get("order_number") or ""
                note = r.get("note") or ""

                line = []
                if date: line.append(date)
                if et: line.append(et)
                if order: line.append(order)
                header = " | ".join(line) if line else "Запис"
                out.append(header)
                if pos: out.append(f"  Посада: {pos}")
                if frm: out.append(f"  Звідки: {frm}")
                if to: out.append(f"  Куди: {to}")
                if src: out.append(f"  Джерело прибуття: {src}")
                if reason: out.append(f"  Причина вибуття: {reason}")
                if note:
                    out.append("  Текст (повністю):")
                    for ln in str(note).splitlines():
                        out.append("    " + ln)
                out.append("")

        return "\n".join(out)

    def _build_settings(self):
        settings_tab.build(self)

    def _pick_template(self):
        p = filedialog.askopenfilename(filetypes=[("XLSX","*.xlsx")])
        if p:
            self.tpl_var.set(p)

    def _apply_settings(self):
        # only template and output dir are mutable in this simple build
        tpl = self.tpl_var.get().strip()
        out = self.out_var.get().strip()
        if not os.path.exists(tpl):
            messagebox.showerror("Помилка", "Шаблон не знайдено.")
            return
        self.template_path = tpl
        self.output_dir = out
        os.makedirs(self.output_dir, exist_ok=True)
        messagebox.showinfo("OK", "Налаштування застосовано.")
        self._scan()

    def _pick_ui_color(self, tag: str):
        """Choose a highlight color for a given tag (settings tab)."""
        try:
            initial = (self.ui_settings.get("colors") or {}).get(tag) or "#ffffff"
            color = colorchooser.askcolor(initialcolor=initial, title=f"Колір — {tag}")[1]
            if not color:
                return
            self.ui_settings.setdefault("colors", {})[tag] = color
            # update button preview if exists
            btn = getattr(self, "_ui_color_buttons", {}).get(tag) if hasattr(self, "_ui_color_buttons") else None
            if btn is not None:
                try:
                    btn.configure(bg=color)
                except Exception:
                    pass
            self._save_ui_settings()
            self._reconfigure_people_text_tags()
        except Exception:
            return

    def _apply_ui_settings_from_controls(self):
        """Apply font + wrap + highlight colors from Settings tab."""
        fam = (getattr(self, "ui_font_family_var", tk.StringVar(value="")).get() or "").strip()
        try:
            size = int((getattr(self, "ui_font_size_var", tk.StringVar(value="12")).get() or "12").strip())
        except Exception:
            size = 12
        wrap_on = bool(getattr(self, "ui_wrap_var", tk.BooleanVar(value=True)).get())

        if fam:
            self.ui_settings.setdefault("font", {})["family"] = fam
        self.ui_settings.setdefault("font", {})["size"] = max(8, min(28, int(size)))
        self.ui_settings["wrap_person_text"] = wrap_on
        self._save_ui_settings()

        # apply globally
        self._apply_global_style()
        for wname in ("person_text", "log", "unknown_units", "unknown_reasons", "unknown_arrivals"):
            w = getattr(self, wname, None)
            if w is not None:
                self._apply_text_widget_style(w)

        if hasattr(self, "person_text"):
            try:
                self.person_text.configure(wrap=("word" if wrap_on else "none"))
            except Exception:
                pass
        self._reconfigure_people_text_tags()
        messagebox.showinfo("OK", "UI налаштування застосовано.")

    def _reset_ui_colors(self):
        defaults = dict(DEFAULT_HIGHLIGHT_COLORS)
        self.ui_settings.setdefault("colors", {}).update(defaults)
        if hasattr(self, "_ui_color_buttons"):
            for k, b in self._ui_color_buttons.items():
                if k in defaults:
                    try:
                        b.configure(bg=defaults[k])
                    except Exception:
                        pass
        self._save_ui_settings()
        self._reconfigure_people_text_tags()

    # ---------- Manual field parse (ручний розбір полів) — Phase 2 dialogs
    def _get_selected_text(self) -> str:
        """Return currently selected text in person_text, or empty string."""
        if not hasattr(self, "person_text"):
            return ""
        try:
            return (self.person_text.get(tk.SEL_FIRST, tk.SEL_LAST) or "").strip()
        except Exception:
            return ""

    def _load_combined(self) -> dict | None:
        if not os.path.exists(self.combined_path):
            return None
        try:
            return load_combined_json(self.combined_path)
        except Exception as e:
            messagebox.showerror("Помилка", f"Не можу прочитати combined_v2.json:\n{e}")
            return None

    def _save_combined(self, data: dict) -> bool:
        try:
            from apps.parser_orders.src.gui.dialogs.manual_fields import save_combined_json
            save_combined_json(data, self.combined_path)
            return True
        except Exception as e:
            messagebox.showerror("Помилка", f"Не можу зберегти combined_v2.json:\n{e}")
            return False

    def _find_record_for_mention(self, person: dict, doc: str, block_id) -> dict | None:
        return find_record_for_mention(person, doc, block_id)

    def _manual_field_parse(self):
        """Open dialog for manual editing (UI in gui.dialogs.manual_fields)."""
        pib = self._current_person_pib or self._get_selected_pib()
        if not pib:
            messagebox.showwarning(
                "Немає людини",
                "Спочатку оберіть людину у списку ПІБ (вкладка «Люди»).",
            )
            return

        selected_text = self._get_selected_text()
        meta = {}
        if hasattr(self, "frag_tree") and hasattr(self, "_frag_meta"):
            sel = self.frag_tree.selection()
            if sel:
                meta = self._frag_meta.get(sel[0]) or {}

        doc = (meta.get("doc") or "").strip()
        block_id = meta.get("block_id")

        combined = self._load_combined()
        if combined is None:
            messagebox.showwarning(
                "Немає даних",
                "Спочатку обробіть DOCX, щоб зʼявився combined_v2.json.",
            )
            return

        person_obj = None
        for p in (combined.get("people") or []):
            if (p.get("pib") or "").strip() == pib:
                person_obj = p
                break
        if person_obj is None:
            messagebox.showwarning("Немає даних", f"Людину «{pib}» не знайдено у combined_v2.json.")
            return

        rec = self._find_record_for_mention(person_obj, doc, block_id) if doc else None
        if rec is None and (person_obj.get("records") or []):
            rec = person_obj["records"][0]
            if not doc:
                doc = (rec.get("doc") or "").strip()
            if block_id is None:
                block_id = rec.get("block_id")

        def _after_save(new_pib: str):
            try:
                self.refresh_people_view()
                if hasattr(self, "people_tree"):
                    for iid in self.people_tree.get_children():
                        vals = self.people_tree.item(iid, "values")
                        if vals and (vals[0] or "").strip() == new_pib:
                            self.people_tree.selection_set(iid)
                            self.people_tree.see(iid)
                            self.show_selected_person()
                            break
            except Exception:
                pass

        open_manual_fields_dialog(
            self,
            pib=pib,
            selected_text=selected_text,
            meta=meta,
            combined=combined,
            person_obj=person_obj,
            rec=rec,
            doc=doc,
            block_id=block_id,
            combined_path=self.combined_path,
            get_selected_text=self._get_selected_text,
            on_after_save=_after_save,
        )



if __name__ == "__main__":
    # Prefer project-root entrypoint: python run_gui.py
    App().mainloop()
