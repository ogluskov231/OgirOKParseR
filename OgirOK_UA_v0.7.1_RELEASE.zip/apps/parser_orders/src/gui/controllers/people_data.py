"""People tab data helpers without Tk (Phase 6)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


def parse_dt_key(s: Optional[str]) -> Tuple:
    """Sort key for date strings dd.mm.yyyy / yyyy-mm-dd / empty last."""
    raw = (s or "").strip()
    if not raw:
        return (1, datetime.max)
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return (0, datetime.strptime(raw[:10], fmt))
        except Exception:
            continue
    return (1, datetime.max)


def build_global_category_index(people: List[dict]) -> Dict[str, dict]:
    """category label -> {count, arrivals, departures, pibs:set}."""
    index: Dict[str, dict] = {}
    for person in people or []:
        pib = (person.get("pib") or "").strip()
        for m in person.get("mentions") or []:
            cat = (m.get("category") or "").strip()
            if not cat:
                continue
            slot = index.setdefault(
                cat, {"count": 0, "arrivals": 0, "departures": 0, "pibs": set()}
            )
            slot["count"] += 1
            if pib:
                slot["pibs"].add(pib)
            et = (m.get("event_type") or "").strip().lower()
            if et == "arrival":
                slot["arrivals"] += 1
            elif et == "departure":
                slot["departures"] += 1
        for r in person.get("records") or []:
            cat = (r.get("category") or "").strip()
            if not cat:
                continue
            # mentions already counted often; still index record-only categories
            if cat not in index:
                index[cat] = {"count": 0, "arrivals": 0, "departures": 0, "pibs": set()}
    return index


def collect_person_export_payload(pib: str, person: dict) -> dict:
    """Stable JSON structure for export_person_json."""
    return {
        "pib": pib,
        "ranks": list(person.get("ranks") or []),
        "records": list(person.get("records") or []),
        "mentions": list(person.get("mentions") or []),
    }


def person_txt_lines(pib: str, person: dict) -> List[str]:
    """Plain-text export lines for one person."""
    lines = [f"ПІБ: {pib}", ""]
    ranks = person.get("ranks") or []
    if ranks:
        lines.append("Звання: " + ", ".join(str(x) for x in ranks))
        lines.append("")
    for i, m in enumerate(person.get("mentions") or [], 1):
        lines.append(
            f"--- Фрагмент {i} | {(m.get('event_type') or '')} | "
            f"{(m.get('category') or '')} | {(m.get('doc') or '')} ---"
        )
        lines.append((m.get("text") or "").strip())
        lines.append("")
    return lines
