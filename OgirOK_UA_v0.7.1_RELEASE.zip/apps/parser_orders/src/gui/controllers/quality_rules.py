"""Quality/rules JSON management without Tk (Phase 7)."""

from __future__ import annotations

import json
import os
import shutil
from typing import Dict, List, Tuple

# name -> relative path under config/
QUALITY_FILE_MAP: Dict[str, str] = {
    "event_categories_rules_v1.json": os.path.join("categories", "event_categories_rules_v1.json"),
    "user_category_rules.json": os.path.join("categories", "user_category_rules.json"),
    "units.json": os.path.join("learning", "units.json"),
    "reasons.json": os.path.join("learning", "reasons.json"),
    "arrival_sources.json": os.path.join("learning", "arrival_sources.json"),
    "events.json": os.path.join("learning", "events.json"),
    "mapping.json": os.path.join("autofill", "mapping.json"),
    "passport_rules.json": os.path.join("autofill", "passport_rules.json"),
    "template_sources.json": os.path.join("autofill", "template_sources.json"),
    "military_order.schema.json": os.path.join("schema", "military_order.schema.json"),
}

QUALITY_HELP_TEXT = (
    "Активні файли:\n"
    "• categories/event_categories_rules_v1.json — базові правила категоризації;\n"
    "• categories/user_category_rules.json — користувацькі правила категоризації;\n"
    "• learning/*.json — словники навчання/розпізнавання;\n"
    "• autofill/mapping.json — мапінг для автозаповнення;\n"
    "• autofill/passport_rules.json — правила автозаповнення;\n"
    "• autofill/template_sources.json — джерела даних шаблону;\n"
    "• schema/military_order.schema.json — контроль структури результату парсингу.\n\n"
    "Файли config/ui_settings.json та config/ignored_people.json не замінюються цією вкладкою, "
    "оскільки вони є налаштуваннями інтерфейсу/списку прихованих людей, а не правилами точності парсера."
)


def validate_json_file(path: str) -> Tuple[bool, str]:
    """Return (ok, message). Empty file or missing → not ok."""
    if not os.path.isfile(path):
        return False, "ВІДСУТНІЙ"
    try:
        with open(path, "r", encoding="utf-8") as f:
            json.load(f)
        return True, "OK"
    except Exception as exc:
        return False, f"ПОМИЛКА JSON: {type(exc).__name__}"


def list_quality_statuses(config_dir: str) -> List[Tuple[str, str, str]]:
    """Rows for quality tree: (filename, destination_rel_or_abs, status)."""
    rows = []
    for name, rel in QUALITY_FILE_MAP.items():
        path = os.path.join(config_dir, rel)
        ok, status = validate_json_file(path)
        rows.append((name, os.path.join("config", rel), status if not ok or status == "OK" else status))
        if ok:
            rows[-1] = (name, os.path.join("config", rel), "OK")
        else:
            rows[-1] = (name, os.path.join("config", rel), status)
    return rows


def import_quality_file(src_path: str, config_dir: str) -> Tuple[bool, str]:
    """Copy src into config by basename mapping. Returns (ok, message)."""
    name = os.path.basename(src_path)
    if name not in QUALITY_FILE_MAP:
        return False, (
            f"Файл «{name}» не входить до списку правил парсера.\n"
            f"Допустимі: {', '.join(QUALITY_FILE_MAP.keys())}"
        )
    rel = QUALITY_FILE_MAP[name]
    dst = os.path.join(config_dir, rel)
    ok, status = validate_json_file(src_path)
    if not ok and status != "ВІДСУТНІЙ":
        return False, f"Джерело не є валідним JSON:\n{status}"
    if not os.path.isfile(src_path):
        return False, f"Файл не знайдено:\n{src_path}"
    # re-validate as JSON object/array
    try:
        with open(src_path, "r", encoding="utf-8") as f:
            json.load(f)
    except Exception as e:
        return False, f"Джерело не є валідним JSON:\n{e}"

    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isfile(dst):
        bak = dst + ".bak"
        try:
            shutil.copy2(dst, bak)
        except Exception:
            pass
    shutil.copy2(src_path, dst)
    return True, f"Імпортовано: {name}\n→ {dst}"


def export_quality_files(config_dir: str, dst_dir: str) -> int:
    """Copy existing quality JSON files to dst_dir. Returns count."""
    count = 0
    for name, rel in QUALITY_FILE_MAP.items():
        src = os.path.join(config_dir, rel)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(dst_dir, name))
            count += 1
    return count
