"""UI widgets helpers: tags, text styles (Phase 4).

Import text_styles as a submodule to avoid requiring tkinter when only tags are needed:

    from apps.parser_orders.src.gui.widgets.tags import ui_tag_for_event_and_category
    from apps.parser_orders.src.gui.widgets import text_styles
"""

from apps.parser_orders.src.gui.widgets.tags import (
    SPECIAL_CATEGORY_TAGS,
    DEFAULT_HIGHLIGHT_COLORS,
    DEFAULT_EVENT_COLORS,
    ui_tag_for_event_and_category,
)

__all__ = [
    "SPECIAL_CATEGORY_TAGS",
    "DEFAULT_HIGHLIGHT_COLORS",
    "DEFAULT_EVENT_COLORS",
    "ui_tag_for_event_and_category",
]
