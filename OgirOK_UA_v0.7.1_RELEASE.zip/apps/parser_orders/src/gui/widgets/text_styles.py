"""Font / color settings and application to Tk widgets (Phase 4)."""

from __future__ import annotations

import json
import os
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk
from typing import Any, Dict, Optional

from apps.parser_orders.src.gui.widgets.tags import (
    DEFAULT_EVENT_COLORS,
    DEFAULT_HIGHLIGHT_COLORS,
)


def default_ui_settings() -> Dict[str, Any]:
    """Default UI settings structure (font + colors + wrap)."""
    try:
        base_font = tkfont.nametofont("TkTextFont")
        fam = base_font.actual("family")
        size = int(base_font.actual("size"))
    except Exception:
        fam, size = "Consolas", 12

    colors = {}
    colors.update(DEFAULT_HIGHLIGHT_COLORS)
    colors.update(DEFAULT_EVENT_COLORS)
    return {
        "font": {"family": fam, "size": size},
        "colors": colors,
        "wrap_person_text": True,
    }


def load_ui_settings(path: str) -> Dict[str, Any]:
    """Load UI settings from JSON path; merge with defaults."""
    defaults = default_ui_settings()
    if not path or not os.path.exists(path):
        return defaults
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return defaults
    except Exception:
        return defaults

    out = defaults
    try:
        if isinstance(data.get("font"), dict):
            out["font"]["family"] = str(data["font"].get("family") or out["font"]["family"])
            out["font"]["size"] = int(data["font"].get("size") or out["font"]["size"])
        if isinstance(data.get("colors"), dict):
            for k, v in data["colors"].items():
                if isinstance(v, str) and v.startswith("#") and len(v) in (4, 7):
                    out["colors"][k] = v
        if "wrap_person_text" in data:
            out["wrap_person_text"] = bool(data.get("wrap_person_text"))
    except Exception:
        return defaults
    return out


def save_ui_settings(path: str, settings: Dict[str, Any]) -> None:
    """Persist UI settings JSON."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)


def apply_global_style(root: tk.Misc, ui_settings: Dict[str, Any]) -> None:
    """Apply font to common ttk widget classes on ``root``."""
    font_family = (ui_settings.get("font") or {}).get("family")
    font_size = int((ui_settings.get("font") or {}).get("size") or 12)
    try:
        style = ttk.Style(root)
        style.configure("TLabel", font=(font_family, font_size))
        style.configure("TButton", font=(font_family, font_size))
        style.configure("TEntry", font=(font_family, font_size))
        style.configure("Treeview", font=(font_family, font_size))
        style.configure("Treeview.Heading", font=(font_family, font_size, "bold"))
    except Exception:
        pass


def apply_text_widget_style(widget: tk.Widget, ui_settings: Dict[str, Any]) -> None:
    """Apply font from settings to a Text/Entry-like widget."""
    font_family = (ui_settings.get("font") or {}).get("family")
    font_size = int((ui_settings.get("font") or {}).get("size") or 12)
    try:
        widget.configure(font=(font_family, font_size))
    except Exception:
        return


def reconfigure_people_text_tags(
    person_text: tk.Text,
    ui_settings: Dict[str, Any],
    font_bold_holder: Optional[dict] = None,
) -> Optional[tkfont.Font]:
    """Configure person_text tags (HDR, BLOCK_ACTIVE, …).

    Returns bold Font object (caller may keep on ``app._font_bold``).
    If ``font_bold_holder`` is a dict, sets ``font_bold_holder['font']``.
    """
    colors = ui_settings.get("colors") or {}
    bold = None
    try:
        base_font = tkfont.Font(person_text, person_text.cget("font"))
        bold = tkfont.Font(person_text, base_font)
        bold.configure(weight="bold")
        person_text.tag_configure("HDR", font=bold)
        if font_bold_holder is not None:
            font_bold_holder["font"] = bold
    except Exception:
        pass
    try:
        for tag, default in DEFAULT_HIGHLIGHT_COLORS.items():
            person_text.tag_configure(tag, background=colors.get(tag, default))
    except Exception:
        pass
    return bold


def apply_tree_event_tags(tree: ttk.Treeview, ui_settings: Dict[str, Any]) -> None:
    """Configure ARRIVAL/DEPARTURE/SPECIAL_* tags on a Treeview."""
    c = ui_settings.get("colors") or {}
    try:
        tree.tag_configure("ARRIVAL", background=c.get("EVT_ARRIVAL", DEFAULT_EVENT_COLORS["EVT_ARRIVAL"]))
        tree.tag_configure(
            "DEPARTURE", background=c.get("EVT_DEPARTURE", DEFAULT_EVENT_COLORS["EVT_DEPARTURE"])
        )
        tree.tag_configure(
            "SPECIAL_MED", background=c.get("EVT_SPECIAL_MED", DEFAULT_EVENT_COLORS["EVT_SPECIAL_MED"])
        )
        tree.tag_configure(
            "SPECIAL_VACATION",
            background=c.get("EVT_SPECIAL_VACATION", DEFAULT_EVENT_COLORS["EVT_SPECIAL_VACATION"]),
        )
        tree.tag_configure(
            "SPECIAL_TRIP",
            background=c.get("EVT_SPECIAL_TRIP", DEFAULT_EVENT_COLORS["EVT_SPECIAL_TRIP"]),
        )
    except Exception:
        pass
