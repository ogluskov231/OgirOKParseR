"""Event/category UI tags and default highlight colors (Phase 4)."""

from __future__ import annotations

from typing import Optional, Tuple

# Special categories (driven by headings) -> UI tags/colors
SPECIAL_CATEGORY_TAGS = {
    "Прикомандировано до медичної роти (в/ч А0989)": "SPECIAL_MED",
    "З щорічної основної відпустки": "SPECIAL_VACATION",
    "У відрядження": "SPECIAL_TRIP",
}

# Text highlight tags (person_text)
DEFAULT_HIGHLIGHT_COLORS = {
    "BLOCK_ACTIVE": "#fff3b0",
    "MATCH_ACTIVE": "#ffe066",
    "CAT_MATCH": "#ffd8a8",
    "PIB_MATCH": "#d3f9d8",
    "FIND": "#cfe8ff",
}

# Treeview / event row backgrounds
DEFAULT_EVENT_COLORS = {
    "EVT_ARRIVAL": "#d3f9d8",
    "EVT_DEPARTURE": "#ffd6d6",
    "EVT_SPECIAL_MED": "#d0ebff",
    "EVT_SPECIAL_VACATION": "#fff3bf",
    "EVT_SPECIAL_TRIP": "#e5dbff",
}


def ui_tag_for_event_and_category(event_type: str, category: Optional[str]) -> Tuple[str, ...]:
    """Return Treeview/Text tags based on category (preferred) and event type."""
    if category:
        t = SPECIAL_CATEGORY_TAGS.get(str(category).strip())
        if t:
            return (t,)
    et = (event_type or "").strip().lower()
    if et == "arrival":
        return ("ARRIVAL",)
    if et == "departure":
        return ("DEPARTURE",)
    return ()
