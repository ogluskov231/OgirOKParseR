"""GUI dialogs extracted in Phase 2 refactor."""

from apps.parser_orders.src.gui.dialogs.rule_from_selection import open_rule_from_selection_dialog
from apps.parser_orders.src.gui.dialogs.manual_fields import open_manual_fields_dialog

__all__ = [
    "open_rule_from_selection_dialog",
    "open_manual_fields_dialog",
]
