"""Dialog: create a category rule from selected phrase (Phase 2).

UI only — persistence is done via ``on_persist`` callback provided by App.
"""

from __future__ import annotations

import re
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Any, Callable, Optional


def open_rule_from_selection_dialog(
    parent: tk.Tk | tk.Toplevel,
    *,
    phrase: str,
    default_event: str = "arrival",
    cat_engine: Any = None,
    make_regex_from_phrase: Optional[Callable[[str], str]] = None,
    on_persist: Optional[Callable[..., None]] = None,
) -> None:
    """Modal dialog to create a user category rule from ``phrase``.

    Parameters
    ----------
    parent:
        Tk root / toplevel (dialog is transient to it).
    phrase:
        Selected text from person view.
    default_event:
        ``arrival`` or ``departure``.
    cat_engine:
        CategoryEngine-like object with ``arrival_labels`` / ``departure_labels``.
    make_regex_from_phrase:
        Callable phrase → regex string (from category_engine).
    on_persist:
        ``on_persist(event_type, label, regex, priority_high)`` — App saves JSON.
    """
    if make_regex_from_phrase is None:
        from apps.parser_orders.src.core.category_engine import make_regex_from_phrase as _mk

        make_regex_from_phrase = _mk

    top = tk.Toplevel(parent)
    top.title("Створити правило з виділення")
    top.geometry("560x260")
    top.transient(parent)
    top.grab_set()

    frm = ttk.Frame(top, padding=12)
    frm.pack(fill="both", expand=True)

    ttk.Label(frm, text="Виділена фраза:").grid(row=0, column=0, sticky="w")
    phrase_var = tk.StringVar(value=phrase)
    ent_phrase = ttk.Entry(frm, textvariable=phrase_var, state="readonly")
    ent_phrase.grid(row=0, column=1, sticky="ew", padx=(8, 0))

    ttk.Label(frm, text="Подія:").grid(row=1, column=0, sticky="w", pady=(8, 0))
    event_var = tk.StringVar(
        value=default_event if default_event in ("arrival", "departure") else "arrival"
    )
    ev_box = ttk.Frame(frm)
    ev_box.grid(row=1, column=1, sticky="w", pady=(8, 0))
    ttk.Radiobutton(ev_box, text="arrival (Надійшло)", variable=event_var, value="arrival").pack(
        side="left"
    )
    ttk.Radiobutton(
        ev_box, text="departure (Вибуло)", variable=event_var, value="departure"
    ).pack(side="left", padx=(10, 0))

    ttk.Label(frm, text="Категорія (label):").grid(row=2, column=0, sticky="w", pady=(8, 0))
    cat_var = tk.StringVar(value="")
    values = []
    if cat_engine:
        values = (
            cat_engine.arrival_labels
            if event_var.get() == "arrival"
            else cat_engine.departure_labels
        )
    cb = ttk.Combobox(frm, textvariable=cat_var, values=values, state="normal")
    cb.grid(row=2, column=1, sticky="ew", padx=(8, 0), pady=(8, 0))

    ttk.Label(frm, text="Regex (match.any):").grid(row=3, column=0, sticky="w", pady=(8, 0))
    regex_var = tk.StringVar(value=make_regex_from_phrase(phrase))
    ent_rx = ttk.Entry(frm, textvariable=regex_var)
    ent_rx.grid(row=3, column=1, sticky="ew", padx=(8, 0), pady=(8, 0))

    prio_var = tk.BooleanVar(value=True)
    ttk.Checkbutton(
        frm, text="Додати вгорі (вищий пріоритет)", variable=prio_var
    ).grid(row=4, column=1, sticky="w", padx=(8, 0), pady=(8, 0))

    def _refresh_cb(*_):
        if not cat_engine:
            cb.configure(values=[])
            return
        cb.configure(
            values=cat_engine.arrival_labels
            if event_var.get() == "arrival"
            else cat_engine.departure_labels
        )

    event_var.trace_add("write", _refresh_cb)

    btns = ttk.Frame(frm)
    btns.grid(row=5, column=0, columnspan=2, sticky="e", pady=(14, 0))
    ttk.Button(btns, text="Скасувати", command=top.destroy).pack(side="right")

    def _save():
        label = (cat_var.get() or "").strip()
        rx = (regex_var.get() or "").strip()
        ev = event_var.get()
        if not label:
            messagebox.showwarning(
                "Нема категорії", "Оберіть або введіть назву категорії (label).", parent=top
            )
            return
        if not rx:
            messagebox.showwarning(
                "Нема regex", "Regex порожній. Вкажіть regex для match.any.", parent=top
            )
            return
        try:
            re.compile(rx, re.IGNORECASE)
        except re.error as e:
            messagebox.showerror("Regex помилка", f"Regex невалідний:\n{e}", parent=top)
            return
        try:
            if on_persist is not None:
                on_persist(
                    event_type=ev,
                    label=label,
                    regex=rx,
                    priority_high=bool(prio_var.get()),
                )
        except Exception as e:
            messagebox.showerror("Помилка", f"Не можу зберегти правило:\n{e}", parent=top)
            return
        top.destroy()

    ttk.Button(btns, text="Зберегти правило", command=_save).pack(side="right", padx=(0, 8))
    frm.columnconfigure(1, weight=1)
