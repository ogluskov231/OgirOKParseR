"""Dialog: manual field edit for a person/fragment (Phase 2).

Applies payload to ``person_obj`` / record / mentions and saves combined JSON
via provided callbacks so App keeps path ownership.
"""

from __future__ import annotations

import json
import os
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Any, Callable, Dict, Optional


def find_record_for_mention(person: dict, doc: str, block_id) -> dict | None:
    """Find a matching record by doc + block_id inside person['records']."""
    try:
        bid = int(block_id) if block_id is not None else None
    except (TypeError, ValueError):
        bid = block_id
    for rec in person.get("records") or []:
        rdoc = (rec.get("doc") or "").strip()
        rbid = rec.get("block_id")
        try:
            rbid = int(rbid) if rbid is not None else None
        except (TypeError, ValueError):
            pass
        if rdoc == (doc or "").strip() and rbid == bid:
            return rec
    return None


def load_combined_json(combined_path: str) -> dict | None:
    if not os.path.exists(combined_path):
        return None
    with open(combined_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_combined_json(data: dict, combined_path: str) -> None:
    os.makedirs(os.path.dirname(combined_path) or ".", exist_ok=True)
    with open(combined_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def apply_manual_payload(
    *,
    person_obj: dict,
    rec: Optional[dict],
    doc: str,
    block_id,
    meta: dict,
    payload: Dict[str, Any],
    original_pib: str,
) -> dict:
    """Mutate person_obj records/mentions from dialog payload. Returns target record."""
    new_pib = (payload.get("pib") or "").strip() or original_pib
    new_event = payload.get("event_type") or "arrival"
    if new_event not in ("arrival", "departure"):
        new_event = "arrival"
    note_val = payload.get("note") or ""

    target_rec = rec
    if target_rec is None:
        target_rec = {
            "pib": new_pib,
            "event_type": new_event,
            "is_attached": False,
            "service_type": "",
            "birth_date": "",
            "block_id": block_id,
            "doc": doc,
            "source_docx": "",
            "section_path": (meta or {}).get("section_path") or [],
            "rule_id": (meta or {}).get("rule_id"),
            "cat_span": (meta or {}).get("cat_span"),
        }
        person_obj.setdefault("records", []).append(target_rec)

    for k, v in payload.items():
        target_rec[k] = v

    ranks = person_obj.setdefault("ranks", [])
    if payload.get("rank") and payload["rank"] not in ranks:
        ranks.append(payload["rank"])

    for m in person_obj.get("mentions") or []:
        mdoc = (m.get("doc") or "").strip()
        mbid = m.get("block_id")
        try:
            mbid = int(mbid) if mbid is not None else None
        except (TypeError, ValueError):
            pass
        try:
            bid_cmp = int(block_id) if block_id is not None else None
        except (TypeError, ValueError):
            bid_cmp = block_id
        if mdoc == (doc or "").strip() and mbid == bid_cmp:
            m["event_type"] = new_event
            m["category"] = payload.get("category")
            m["date"] = (
                payload.get("arrival_date")
                if new_event == "arrival"
                else payload.get("departure_date")
            )
            if note_val:
                m["text"] = note_val
            break

    if new_pib != original_pib:
        person_obj["pib"] = new_pib
        for r0 in person_obj.get("records") or []:
            r0["pib"] = new_pib

    return target_rec


def open_manual_fields_dialog(
    parent: tk.Tk | tk.Toplevel,
    *,
    pib: str,
    selected_text: str = "",
    meta: Optional[dict] = None,
    combined: dict,
    person_obj: dict,
    rec: Optional[dict],
    doc: str = "",
    block_id=None,
    combined_path: str,
    get_selected_text: Optional[Callable[[], str]] = None,
    on_after_save: Optional[Callable[[str], None]] = None,
) -> None:
    """Open modal form to edit structured fields for one person/fragment."""
    meta = meta or {}
    mention_text = (meta.get("text") or "").strip()

    def _v(key, default=""):
        if rec and rec.get(key) not in (None, ""):
            return str(rec.get(key))
        return default

    event_default = _v("event_type") or (meta.get("event_type") or "arrival")
    if event_default not in ("arrival", "departure"):
        event_default = "arrival"

    top = tk.Toplevel(parent)
    top.title(f"Ручний розбір полів — {pib}")
    top.geometry("720x560")
    top.transient(parent)
    top.grab_set()

    outer = ttk.Frame(top, padding=12)
    outer.pack(fill="both", expand=True)

    info = ttk.Label(
        outer,
        text=(
            f"Документ: {doc or '—'}   |   Блок: {block_id if block_id is not None else '—'}\n"
            f"Виділений текст: "
            f"{(selected_text[:120] + '…') if len(selected_text) > 120 else (selected_text or '—')}"
        ),
        justify="left",
    )
    info.pack(anchor="w", pady=(0, 8))

    canvas = tk.Canvas(outer, highlightthickness=0)
    vsb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    form = ttk.Frame(canvas)
    form.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=form, anchor="nw")
    canvas.configure(yscrollcommand=vsb.set)
    canvas.pack(side="left", fill="both", expand=True)
    vsb.pack(side="right", fill="y")

    fields: Dict[str, tk.Variable] = {}
    last_focused = {"widget": None}

    def _add_row(row: int, label: str, key: str, value: str = "", width: int = 55):
        ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", pady=3, padx=(0, 8))
        var = tk.StringVar(value=value)
        ent = ttk.Entry(form, textvariable=var, width=width)
        ent.grid(row=row, column=1, sticky="ew", pady=3)
        ent.bind("<FocusIn>", lambda e, w=ent: last_focused.update(widget=w))
        fields[key] = var
        return ent

    r = 0
    _add_row(r, "ПІБ", "pib", _v("pib", pib))
    r += 1
    _add_row(r, "Звання", "rank", _v("rank"))
    r += 1

    ttk.Label(form, text="Категорія звання").grid(row=r, column=0, sticky="w", pady=3, padx=(0, 8))
    rank_cat_var = tk.StringVar(value=_v("rank_category"))
    rank_cat_cb = ttk.Combobox(
        form,
        textvariable=rank_cat_var,
        values=["", "Солдат", "Сержант", "Офіцер"],
        state="normal",
        width=52,
    )
    rank_cat_cb.grid(row=r, column=1, sticky="ew", pady=3)
    rank_cat_cb.bind("<FocusIn>", lambda e, w=rank_cat_cb: last_focused.update(widget=w))
    fields["rank_category"] = rank_cat_var
    r += 1

    ttk.Label(form, text="Тип події").grid(row=r, column=0, sticky="w", pady=3, padx=(0, 8))
    event_var = tk.StringVar(value=event_default)
    ev_box = ttk.Frame(form)
    ev_box.grid(row=r, column=1, sticky="w", pady=3)
    ttk.Radiobutton(ev_box, text="Надійшло (arrival)", variable=event_var, value="arrival").pack(
        side="left"
    )
    ttk.Radiobutton(
        ev_box, text="Вибуло (departure)", variable=event_var, value="departure"
    ).pack(side="left", padx=(12, 0))
    fields["event_type"] = event_var
    r += 1

    _add_row(r, "Посада", "position", _v("position"))
    r += 1
    _add_row(r, "З підрозділу", "from_unit", _v("from_unit"))
    r += 1
    _add_row(r, "До підрозділу", "to_unit", _v("to_unit"))
    r += 1
    meta_date = (meta.get("date") or "").strip()
    arr_prefill = _v("arrival_date") or (meta_date if event_default == "arrival" else "")
    dep_prefill = _v("departure_date") or (meta_date if event_default == "departure" else "")
    _add_row(r, "Дата прибуття", "arrival_date", arr_prefill)
    r += 1
    _add_row(r, "Дата вибуття", "departure_date", dep_prefill)
    r += 1
    _add_row(r, "Джерело прибуття", "arrival_source", _v("arrival_source"))
    r += 1
    _add_row(r, "Причина вибуття", "departure_reason", _v("departure_reason"))
    r += 1
    _add_row(r, "Категорія (парсер)", "category", _v("category") or (meta.get("category") or ""))
    r += 1
    _add_row(r, "Номер наказу", "order_number", _v("order_number"))
    r += 1

    ttk.Label(form, text="Примітка / текст").grid(row=r, column=0, sticky="nw", pady=3, padx=(0, 8))
    note_frame = ttk.Frame(form)
    note_frame.grid(row=r, column=1, sticky="ew", pady=3)
    note_txt = tk.Text(note_frame, height=5, width=55, wrap="word")
    note_txt.insert("1.0", _v("note") or mention_text or selected_text)
    note_ysb = ttk.Scrollbar(note_frame, orient="vertical", command=note_txt.yview)
    note_txt.configure(yscrollcommand=note_ysb.set)
    note_txt.pack(side="left", fill="both", expand=True)
    note_ysb.pack(side="right", fill="y")
    note_txt.bind("<FocusIn>", lambda e, w=note_txt: last_focused.update(widget=w))
    form.columnconfigure(1, weight=1)

    actions = ttk.Frame(top, padding=(12, 0, 12, 12))
    actions.pack(fill="x")

    def _paste_selection_into_focus():
        text = selected_text
        if not text and get_selected_text:
            text = get_selected_text() or ""
        if not text:
            messagebox.showinfo(
                "Нема виділення",
                "Виділіть фрагмент тексту у правій панелі, потім натисніть цю кнопку.",
                parent=top,
            )
            return
        w = last_focused.get("widget")
        if w is None:
            messagebox.showinfo(
                "Фокус",
                "Спочатку клацніть у потрібне поле, куди вставити виділене.",
                parent=top,
            )
            return
        try:
            if isinstance(w, tk.Text):
                w.insert(tk.INSERT, text)
            else:
                try:
                    w.delete(0, "end")
                    w.insert(0, text)
                except Exception:
                    pass
        except Exception as e:
            messagebox.showerror("Помилка", str(e), parent=top)

    def _save():
        new_pib = (fields["pib"].get() or "").strip() or pib
        new_event = fields["event_type"].get()
        if new_event not in ("arrival", "departure"):
            new_event = "arrival"
        note_val = note_txt.get("1.0", "end").strip()
        payload = {
            "pib": new_pib,
            "event_type": new_event,
            "rank": (fields["rank"].get() or "").strip(),
            "rank_category": (fields["rank_category"].get() or "").strip(),
            "position": (fields["position"].get() or "").strip(),
            "from_unit": (fields["from_unit"].get() or "").strip(),
            "to_unit": (fields["to_unit"].get() or "").strip(),
            "arrival_date": (fields["arrival_date"].get() or "").strip(),
            "departure_date": (fields["departure_date"].get() or "").strip(),
            "arrival_source": (fields["arrival_source"].get() or "").strip(),
            "departure_reason": (fields["departure_reason"].get() or "").strip(),
            "category": (fields["category"].get() or "").strip() or None,
            "order_number": (fields["order_number"].get() or "").strip(),
            "note": note_val,
        }
        try:
            apply_manual_payload(
                person_obj=person_obj,
                rec=rec,
                doc=doc,
                block_id=block_id,
                meta=meta,
                payload=payload,
                original_pib=pib,
            )
            save_combined_json(combined, combined_path)
        except Exception as e:
            messagebox.showerror("Помилка", f"Не можу зберегти combined_v2.json:\n{e}", parent=top)
            return

        top.destroy()
        if on_after_save is not None:
            try:
                on_after_save(new_pib)
            except Exception:
                pass
        messagebox.showinfo("Збережено", "Поля оновлено і записано у combined_v2.json.", parent=parent)

    ttk.Button(actions, text="📋 Вставити виділене в поле", command=_paste_selection_into_focus).pack(
        side="left"
    )
    ttk.Button(actions, text="Скасувати", command=top.destroy).pack(side="right")
    ttk.Button(actions, text="💾 Зберегти", command=_save).pack(side="right", padx=(0, 8))

    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _on_close():
        try:
            canvas.unbind_all("<MouseWheel>")
        except Exception:
            pass
        top.destroy()

    top.protocol("WM_DELETE_WINDOW", _on_close)
