"""ОгрОК_UA — parser_orders application package."""

from pathlib import Path

def _read_version() -> str:
    # apps/parser_orders -> apps -> project root
    root = Path(__file__).resolve().parents[2]
    vf = root / "VERSION"
    if vf.is_file():
        return vf.read_text(encoding="utf-8").strip()
    return "0.0.0-dev"

__version__ = _read_version()
