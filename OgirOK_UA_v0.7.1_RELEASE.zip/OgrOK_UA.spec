# -*- mode: python ; coding: utf-8 -*
# ОгрОК_UA v0.7.1 — entry run_gui.py + hiddenimports (Phases 1–10)

_hidden = [
    "apps.parser_orders.src.services",
    "apps.parser_orders.src.services.pipeline_service",
    "apps.parser_orders.src.services.app_paths",
    "apps.parser_orders.src.gui.controllers",
    "apps.parser_orders.src.gui.controllers.people_data",
    "apps.parser_orders.src.gui.controllers.quality_rules",

    "apps.parser_orders.src.gui.dialogs",
    "apps.parser_orders.src.gui.dialogs.rule_from_selection",
    "apps.parser_orders.src.gui.dialogs.manual_fields",
    "apps.parser_orders.src.gui.tabs",
    "apps.parser_orders.src.gui.tabs.input_tab",
    "apps.parser_orders.src.gui.tabs.run_tab",
    "apps.parser_orders.src.gui.tabs.results_tab",
    "apps.parser_orders.src.gui.tabs.quality_tab",
    "apps.parser_orders.src.gui.tabs.people_tab",
    "apps.parser_orders.src.gui.tabs.settings_tab",
    "apps.parser_orders.src.gui.widgets",
    "apps.parser_orders.src.gui.widgets.tags",
    "apps.parser_orders.src.gui.widgets.text_styles",
    "apps.parser_orders.src.core.docx_parser",
    "apps.parser_orders.src.core.excel_autofill",
    "apps.parser_orders.src.core.category_engine",
    "apps.parser_orders.src.core.json_schema",
    "apps.parser_orders.src.core.rules_manager",
    "apps.parser_orders.src.core.diagnostics",
    "apps.parser_orders.src.core.os_utils",
    "docx",
    "openpyxl",
    "openpyxl.cell._writer",
]

a = Analysis(
    ["run_gui.py"],
    pathex=[],
    binaries=[],
    datas=[
        ("templates", "templates"),
        ("config", "config"),
        ("assets", "assets"),
        ("input", "input"),
    ],
    hiddenimports=_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="OgrOK_UA",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=["assets\\icon.ico"],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="OgrOK_UA",
)
