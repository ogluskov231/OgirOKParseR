#!/usr/bin/env python3
"""Thin GUI entrypoint for ОгрОК_UA (Phase 5).

Use this as the PyInstaller script and for local runs:

    python run_gui.py
    pyinstaller OgrOK_UA.spec

Keeps ``parser_gui.py`` as the App module (not the freeze entry),
so analysis collects packages under ``apps.parser_orders`` cleanly.
"""

from __future__ import annotations

import os
import sys

# Project root = directory of this file
_ROOT = os.path.abspath(os.path.dirname(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)


def main() -> int:
    from apps.parser_orders.src.gui.parser_gui import App

    app = App()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
