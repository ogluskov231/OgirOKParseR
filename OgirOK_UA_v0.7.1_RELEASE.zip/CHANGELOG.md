# CHANGELOG — ОгрОК_UA

## 0.7.1

Покращена **Phase 10** (релізний каркас):

- Файл **`VERSION`** — єдине джерело версії; `apps.parser_orders.__version__` читає його
- Розширений **`scripts/smoke_check.py`**: структура, синхрон версій, AST-синтаксис, mapping/template, критичні імпорти, unittest
- **`docs/RELEASE_CHECKLIST_UA.md`** — покроковий чеклист релізу
- Узгоджено `BUILD_WINDOWS.md`, `OgrOK_UA.spec`, ISS, README під 0.7.1

## 0.7.0 (Phases 6–10)

- Controllers: `gui/controllers/people_data.py`, `quality_rules.py`
- Central paths: `services/app_paths.py`
- Tests: `tests/test_phase6_10_helpers.py`
- Docs: `ARCHITECTURE.md`, `PHASE6_10_UA.md`

## 0.6.7 (Phase 5)

- Entrypoint `run_gui.py`
- PyInstaller `OgrOK_UA.spec` + hiddenimports

## 0.6.6 (Phase 4)

- `gui/widgets/` — tags, text_styles

## 0.6.5 (Phase 3)

- `gui/tabs/` — Notebook builders

## 0.6.4 (Phase 2)

- `gui/dialogs/` — manual fields, rule from selection

## 0.6.3 (Phase 1)

- `services/pipeline_service.py` — DOCX→JSON→Excel without UI

## 0.6.2

- Excel autofill from JSON (GUI + CLI `--from-json`)

## 0.6.1

- Manual field parse dialog
