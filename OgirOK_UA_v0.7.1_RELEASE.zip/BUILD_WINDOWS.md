# Підготовка Windows-релізу (v0.7.1)

Повний чеклист: `docs/RELEASE_CHECKLIST_UA.md`.

## 0. Версія

Єдине джерело: файл **`VERSION`** у корені (зараз `0.7.1`).

Перед збіркою: `python scripts/smoke_check.py` (має бути Version sync OK).

## 1. Локальний запуск (без .exe)

```text
python run_gui.py
```

або `RUN_GUI.bat`.

CLI:

```text
python run_parser_orders_cli.py --input input\documents --excel --json
python run_parser_orders_cli.py --from-json output\parsed\combined_v2.json --excel
```

## 2. Збірка .exe

```text
scripts\build_exe_windows.bat
```

Використовує **`OgrOK_UA.spec`** (entrypoint `run_gui.py` + hiddenimports).

Результат: `dist\OgrOK_UA\OgrOK_UA.exe`

Datas: `templates`, `config`, `assets`, `input`.

## 3. Установник (Inno Setup)

`installer\OgrOK_UA.iss` (`MyAppVersion` = вміст `VERSION`) → Compile.

Вихід: `installer_output\OgrOK_UA_Setup_v0.7.1.exe`

## 4. Перевірка freeze

1. Exe на машині без окремого Python.
2. DOCX → Excel + JSON; Excel з JSON; ручний розбір; правило з виділення.
3. `ModuleNotFoundError` → додати модуль у `_hidden` у `OgrOK_UA.spec`.

## Що не пакувати в zip сирців

`.venv`, `build`, `dist`, `__pycache__`, `output/*`, реальні файли в `input/documents`.
