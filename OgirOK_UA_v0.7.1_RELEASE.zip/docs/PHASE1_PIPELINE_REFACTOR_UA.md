# Фаза 1 рефакторингу GUI — винесення `pipeline_service`

**Версія проєкту:** ОгрОК_UA v0.6.3 (Phase 1)  
**Мета:** винести логіку «DOCX → JSON → Excel» і «JSON → Excel» з Tkinter-GUI у модуль **без UI**, **без зміни поведінки** для користувача.

---

## Зміст

1. [Що зроблено (коротко)](#1-що-зроблено-коротко)
2. [Нова структура тек](#2-нова-структура-тек)
3. [Файл `services/__init__.py`](#3-файл-services__init__py)
4. [Файл `services/pipeline_service.py` — розбір від А до Я](#4-файл-servicespipeline_servicepy--розбір-від-а-до-я)
5. [Зміни в `parser_gui.py`](#5-зміни-в-parser_guipy)
6. [Зміни в `run_parser_orders_cli.py`](#6-зміни-в-run_parser_orders_clipy)
7. [Що НЕ змінювалось](#7-що-не-змінювалось)
8. [Як перевірити (smoke)](#8-як-перевірити-smoke)
9. [Як читати / правити далі](#9-як-читати--правити-далі)
10. [Наступні фази (орієнтир)](#10-наступні-фази-орієнтир)

---

## 1. Що зроблено (коротко)

| Було | Стало |
|------|--------|
| `App._run_pipeline` містив виклики `build_combined_v2`, запис JSON, flatten records, `autofill_template` | Те саме в `run_docx_pipeline()`; GUI лише прогрес/лог/messagebox |
| `App._run_autofill_from_json_path` викликав `autofill_from_json_file` напряму | Те саме в `run_json_autofill()`; GUI — оболонка |
| Дубльований цикл flatten у GUI і CLI | Спільна `flatten_records()` |

**Поведінка для користувача:** ті самі кнопки, ті самі шляхи файлів (`combined_v2.json`, `N_filled_*.xlsx`, `unknowns_latest.json`), ті самі повідомлення про помилки (з невеликим узагальненням текстів через `PipelineResult.error_message`).

---

## 2. Нова структура тек

```text
apps/parser_orders/src/
├── core/                    # без змін у Фазі 1 (docx_parser, excel_autofill, …)
├── gui/
│   └── parser_gui.py        # змінено: імпорти + тонкі обгортки pipeline
└── services/                # ★ НОВЕ
    ├── __init__.py          # реекспорт публічного API сервісу
    └── pipeline_service.py  # логіка конвеєра без Tkinter
```

Чому `services/`, а не всередині `gui/`:
- сервіс **не залежить** від Tkinter;
- CLI і майбутні тести можуть імпортувати той самий код;
- наступні фази (вкладки, діалоги) не змішуватимуть UI і бізнес-логіку.

---

## 3. Файл `services/__init__.py`

**Призначення:** зручний імпорт:

```python
from apps.parser_orders.src.services import run_docx_pipeline, flatten_records
```

**Вміст:** імпорт з `pipeline_service` і список `__all__`.

Нічого не виконує при імпорті, окрім завантаження модуля сервісу.

---

## 4. Файл `services/pipeline_service.py` — розбір від А до Я

### 4.1. Імпорти

- `json`, `os` — запис combined JSON і перевірка шляхів.
- `dataclasses` — `PipelinePaths`, `PipelineResult`.
- `typing` — анотації.
- **Немає** `tkinter`, `messagebox`, `filedialog`.

Важкі імпорти `build_combined_v2` / `autofill_*` зроблено **всередині функцій** (`run_docx_pipeline`, `run_json_autofill`), щоб:
- швидше імпортувати модуль у тестах;
- уникнути циклічних залежностей;
- не тягнути openpyxl/docx, якщо потрібна лише `flatten_records`.

### 4.2. `PipelinePaths` (dataclass)

Поля — ті самі шляхи, що вже тримає `App`:

| Поле | Звідки в App | Навіщо |
|------|----------------|--------|
| `template_path` | `templates/N_fixed.xlsx` | Шаблон Excel |
| `rules_path` | `config/autofill/passport_rules.json` | Сумісність autofill |
| `mapping_path` | `config/autofill/mapping.json` | Колонки / routing |
| `learning_dir` | `config/learning` | Словники самонавчання |
| `output_dir` | `output/exports/excel` | Куди писати `N_filled_*.xlsx` |
| `parsed_dir` | `output/parsed` | Тека combined |
| `diag_path` | `output/diagnostics/unknowns_latest.json` | Діагностика |
| `combined_path` | `output/parsed/combined_v2.json` | Шлях збереження combined |

Метод **`ensure_dirs()`** створює `output_dir`, `parsed_dir`, батьківську теку для `diag_path`, щоб запис не падав через відсутні папки.

### 4.3. `PipelineResult` (dataclass)

Єдиний об’єкт відповіді сервісу:

| Поле | Значення |
|------|----------|
| `ok` | `True`, якщо конвеєр успішно завершився |
| `combined` | dict combined (після DOCX-парсингу) |
| `combined_path` | шлях до JSON (збереженого або вхідного) |
| `excel_path` | шлях до `N_filled_*.xlsx` |
| `records_count` | кількість плоских записів |
| `processed_files` | успішні DOCX |
| `errors` | помилки парсингу по файлах |
| `error_message` | короткий текст для messagebox |
| `log_lines` | рядки для вкладки «Обробка» |

GUI **не парсить exceptions** з сервісу для основного шляху: сервіс ловить помилки і кладе в `PipelineResult`.

### 4.4. `flatten_records(combined)`

**Що робить:** обходить `combined["people"]` і збирає `records`, підставляючи `pib` з особи, якщо в записі порожньо.

**Чому важливо:** Excel autofill очікує **плоский** список dict, а не дерево people.

**Ідемпотентність щодо старого коду:** той самий алгоритм, що був у `_run_pipeline` і CLI.

### 4.5. `save_combined_json(combined, combined_path)`

Створює батьківську теку, пише UTF-8 JSON з `indent=2`, `ensure_ascii=False` — як раніше в GUI.

### 4.6. `run_docx_pipeline(docx_files, paths)`

Покроково (як колишній `_run_pipeline`):

1. Порожній список DOCX → `ok=False`, повідомлення.
2. `paths.ensure_dirs()`.
3. `build_combined_v2(...)`.
4. Заповнити `processed_files` / `errors` / log.
5. Якщо жоден файл не оброблено і є errors → `ok=False` (GUI покаже помилку).
6. `save_combined_json` → `combined_path`.
7. `flatten_records` → `autofill_template(...)`.
8. При успіху Excel: `ok=True`, `excel_path=...`.

Якщо Excel упав після успішного JSON — `combined_path` уже встановлений, `ok=False` (частковий результат; GUI може залишити `last_json`).

### 4.7. `run_json_autofill(json_path, paths)`

1. Перевірка існування JSON і template.
2. `autofill_from_json_file(...)` з core.
3. Успіх → `ok=True`, `excel_path`, `records_count`, `combined_path=json_path` (шлях джерела, не обов’язково `combined_v2.json`).

Помилки `FileNotFoundError` / `ValueError` / інші → `error_message` + log.

### 4.8. `paths_from_app_dirs(...)`

Зручний конструктор `PipelinePaths` з іменованих аргументів — щоб у `App` не збирати dataclass вручну довгим літералом.

---

## 5. Зміни в `parser_gui.py`

### 5.1. Імпорти

**Прибрано** прямі:

- `autofill_template`, `autofill_from_json_file`
- `build_combined_v2`

**Додано:**

```python
from apps.parser_orders.src.services.pipeline_service import (
    paths_from_app_dirs,
    run_docx_pipeline,
    run_json_autofill,
)
```

Решта GUI-імпортів (CategoryEngine, open_path, load_unknowns) без змін.

### 5.2. Новий метод `_pipeline_paths(self)`

Збирає `PipelinePaths` з `self.template_path`, `self.rules_path`, … — **одне місце**, якщо шляхи App зміняться в налаштуваннях.

### 5.3. `_run_pipeline(self, docx_files)`

Тепер:

1. UI: progress 0, status, log «Парсинг…», `update()`.
2. `result = run_docx_pipeline(docx_files, self._pipeline_paths())`.
3. Допис `result.log_lines` у журнал (без дубля першого рядка парсингу).
4. Якщо `not result.ok` → messagebox + status «Помилка».
5. Якщо ok → `last_json`, `last_excel`, `_refresh_results`, `refresh_people_view`, `_refresh_quality_tree`, status «Готово».

Кнопки **Обробити все / Обробити вибране / AUTO** як і раніше викликають `_run_pipeline`.

### 5.4. `_run_autofill_from_json_path(self, json_path)`

1. Перевірка template (як раніше, до виклику сервісу).
2. Перемикання на вкладку «Обробка», progress.
3. `run_json_autofill(...)`.
4. Log + messagebox за типом тексту помилки (не знайдено / немає записів / інше).
5. Успіх → `last_excel`, `last_json`, refresh results, info dialog.

`_autofill_from_combined` і `_autofill_from_json_file` **не змінювали** — вони як і раніше лише обирають шлях і викликають `_run_autofill_from_json_path`.

---

## 6. Зміни в `run_parser_orders_cli.py`

- Імпорт `flatten_records`.
- Замість локального циклу `for person in combined...` → `records = flatten_records(combined)`.

Режим `--from-json` як і раніше використовує `autofill_from_json_file` напряму (еквівалентно сервісу; можна пізніше перевести на `run_json_autofill` для повної уніфікації логів).

---

## 7. Що НЕ змінювалось

- `core/docx_parser.py`, `core/excel_autofill.py` — без змін алгоритму.
- `config/`, `templates/`, кнопки GUI, вкладки, ручний розбір полів.
- Імена вихідних файлів і розташування `output/`.
- Точка входу PyInstaller: як і раніше `apps/parser_orders/src/gui/parser_gui.py`.
- Пакет `services` потрапляє в exe автоматично через імпорт з `parser_gui` (hiddenimports зазвичай не потрібні, бо імпорт явний). Якщо збірка «не бачить» модуль — додати в spec:
  `--hidden-import apps.parser_orders.src.services.pipeline_service`

---

## 8. Як перевірити (smoke)

На Windows (або Linux з Tkinter):

```text
1. Розпакувати архів проєкту
2. pip install -r requirements.txt
3. Покласти тестовий DOCX у input/documents/
4. python apps/parser_orders/src/gui/parser_gui.py
   або RUN_GUI.bat
5. Обробити → з’являються combined_v2.json і N_filled_*.xlsx
6. Кнопка «📊 З combined_v2.json» / «Excel з JSON-файлу» → новий xlsx
7. CLI:
   python run_parser_orders_cli.py --input input/documents --excel --json
   python run_parser_orders_cli.py --from-json output/parsed/combined_v2.json --excel
```

Без GUI (лише логіка):

```python
from apps.parser_orders.src.services.pipeline_service import (
    flatten_records, PipelinePaths, run_docx_pipeline
)
# ...
```

---

## 9. Як читати / правити далі

| Задача | Куди йти |
|--------|----------|
| Змінити порядок кроків parse→excel | `pipeline_service.run_docx_pipeline` |
| Змінити текст у messagebox / прогрес | `parser_gui._run_pipeline` / `_run_autofill_from_json_path` |
| Змінити витяг полів з DOCX | `core/docx_parser.py` |
| Змінити колонки Excel | `config/autofill/mapping.json` + за потреби normalize в excel_autofill |
| Додати поле в flatten | зазвичай не потрібно; flatten лише копіює records |
| Новий тип результату для GUI | розширити `PipelineResult` |

**Правило Фази 1:** не повертати бізнес-логіку (запис JSON, виклик autofill) назад у довгі методи `App`.

---

## 10. Наступні фази (орієнтир)

| Фаза | Зміст |
|------|--------|
| **2** | Діалоги: manual fields, rule from selection → `gui/dialogs/` |
| **3** | Вкладки → `gui/tabs/` (results, input, people, …) |
| **4** | Стилі тексту / tags → `gui/widgets/` |
| **5** | Тонкий entrypoint; за потреби оновити PyInstaller |

Фаза 1 **завершена**, якщо smoke з розділу 8 проходить і немає регресії кнопок Excel з JSON / Обробити.

---

## Додаток: схема викликів

```text
[Кнопка Обробити]
    → App._run_pipeline
        → run_docx_pipeline
            → build_combined_v2
            → save_combined_json
            → flatten_records
            → autofill_template
        → App: log, messagebox, refresh UI

[Кнопка Excel з JSON]
    → App._autofill_from_json_file / _autofill_from_combined
        → App._run_autofill_from_json_path
            → run_json_autofill
                → autofill_from_json_file
            → App: log, messagebox, refresh
```

---

*Документ стосується лише Фази 1. Інші модулі проєкту описані в загальному аудиті / README.*
