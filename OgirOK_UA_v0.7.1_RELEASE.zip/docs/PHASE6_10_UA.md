# Фази 6–10 — controllers, paths, тести, релізний каркас

**Версія:** ОгрОК_UA **v0.7.0**

## Фаза 6 — `gui/controllers/people_data.py`

Винесено без Tk:

- `parse_dt_key` — сортування дат
- `build_global_category_index` — індекс категорій по people
- `collect_person_export_payload` / `person_txt_lines` — експорт

`App._parse_dt` / `_build_global_category_index` делегують у controller.

## Фаза 7 — `gui/controllers/quality_rules.py`

- `QUALITY_FILE_MAP`, `QUALITY_HELP_TEXT`
- `validate_json_file`, `list_quality_statuses`
- `import_quality_file`, `export_quality_files`

Вкладка «Правила парсера» лишає лише UI (messagebox / tree); логіка файлів — у controller.

## Фаза 8 — `services/app_paths.py`

- `resolve_base_dir` (source vs PyInstaller frozen)
- `AppPaths` dataclass: templates, config, output, docs, combined_json, …
- `parser_gui` модульні `BASE_DIR`/`CONFIG`/… беруться з `get_app_paths(PROJECT_ROOT)`

## Фаза 9 — тести

- `tests/test_phase6_10_helpers.py` — people, quality, tags, flatten, paths
- Існуючі `test_json_schema.py`, `test_special_categories.py` лишаються

Запуск: `python -m unittest discover -s tests -v` або `python scripts/smoke_check.py`

## Фаза 10 — релізний каркас

- `docs/ARCHITECTURE.md` — огляд системи
- `docs/PHASE6_10_UA.md` — цей документ
- `CHANGELOG.md` — історія 0.6.x → 0.7.0
- `scripts/smoke_check.py` — імпорти + unittest
- Версія **0.7.0** у README / ISS / docs
- Spec hiddenimports: `controllers`, `app_paths`

## Smoke

```text
python scripts/smoke_check.py
python run_gui.py
```
