# Фаза 3 рефакторингу GUI — винесення вкладок

**Версія:** ОгрОК_UA v0.6.5 (Phase 3)  
**Мета:** винести **побудову UI вкладок** Notebook з `parser_gui.App` у пакет `gui/tabs/`, без зміни поведінки.

---

## 1. Що зроблено

| Метод App (було) | Модуль (стало) |
|------------------|----------------|
| `_build_input` | `tabs/input_tab.py` → `build(app)` |
| `_build_run` | `tabs/run_tab.py` → `build(app)` |
| `_build_results` | `tabs/results_tab.py` → `build(app)` |
| `_build_quality_rules` | `tabs/quality_tab.py` → `build(app)` |
| `build_people` | `tabs/people_tab.py` → `build(app)` |
| `_build_settings` | `tabs/settings_tab.py` → `build(app)` |

У `parser_gui.py` ці методи стали однорядковими:

```python
def _build_input(self):
    input_tab.build(self)
```

**Логіка обробки** (pipeline, scan, people refresh, quality import, settings apply) **залишилась у `App`**. Фаза 3 переносить лише **конструкцію віджетів**.

---

## 2. Структура

```text
apps/parser_orders/src/gui/
├── parser_gui.py          # App + обробники подій
├── dialogs/               # Phase 2
└── tabs/                  # ★ Phase 3
    ├── __init__.py
    ├── input_tab.py
    ├── run_tab.py
    ├── results_tab.py
    ├── quality_tab.py
    ├── people_tab.py
    └── settings_tab.py
```

Разом із Phase 1–2:

```text
src/
├── core/
├── services/pipeline_service.py
└── gui/
    ├── parser_gui.py
    ├── dialogs/
    └── tabs/
```

---

## 3. Контракт `build(app)`

Кожен модуль експортує:

```python
def build(app) -> None:
    ...
```

- `app` — екземпляр `App` (має `tab_input`, `tab_run`, … і методи-команди).
- Віджети, які раніше були `self.tree`, `self.log`, … як і раніше вішаються на **атрибути app** (`app.tree`, `app.log`, …), щоб решта коду App не ламалась.
- `command=app._run_default` тощо — ті самі обробники.

Допоміжні функції в кожному файлі (де потрібно):

| Функція | Призначення |
|---------|-------------|
| `_config_dir(app)` | `dirname(app.learning_dir)` → `config/` |
| `_output_root(app)` | батько `parsed_dir` → `output/` |

Так вкладки **не імпортують** `parser_gui` (немає циклічного імпорту) і не залежать від глобальних `CONFIG`/`OUTPUT`.

---

## 4. Розбір вкладок

### 4.1. `input_tab.py`
- Entry шляху, кнопки Файл / Папка / Сканувати
- Treeview знайдених DOCX
- Обробити все / вибране / Excel з JSON

### 4.2. `run_tab.py`
- `status_var`, Progressbar, Text-лог
- Очистити лог, відкрити output, Excel з JSON

### 4.3. `results_tab.py`
- Шляхи останнього Excel/JSON/diagnostics
- Кнопки відкрити + autofill з JSON

### 4.4. `quality_tab.py`
- Treeview JSON-правил
- Імпорт / перевірка / експорт / відкрити config

### 4.5. `people_tab.py` (найбільший)
- Toolbar (оновити, експорт, правило, ручний розбір, Excel…)
- Sidebar: ПІБ, документи, категорії
- Текст людини + fragments tree + пошук

### 4.6. `settings_tab.py`
- Шлях шаблону, DOCX folder, output
- Шрифт, кольори підсвітки (кнопки викликають `app._pick_ui_color` тощо)

Шлях `input/documents` у settings обчислюється від `output` / `template_path` (еквівалент колишнього `DOCS_DIR` у нормальному layout проєкту).

---

## 5. Що навмисно НЕ виносилось у Фазі 3

- `_scan`, `_run_pipeline`, `_run_autofill_*`
- `refresh_people_view`, `_render_person_into_ui`, експорт людей
- `_import_quality_json`, `_validate_quality_jsons`
- `_apply_settings`, `_pick_ui_color`
- Діалоги (вже Phase 2)

Їх можна винести пізніше в `tabs/people_controller.py` тощо (Фаза 3b), коли знадобиться.

---

## 6. Циклічні імпорти

```text
parser_gui → tabs.* → (тільки core.os_utils + stdlib)
tabs.*  НЕ → parser_gui
```

Безпечно для PyInstaller: явні імпорти tabs у `parser_gui`.

---

## 7. Smoke

1. Старт GUI — усі 6 вкладок на місці.
2. Вхід: скан + обробка DOCX.
3. Обробка: лог і progress.
4. Результати: шляхи + Excel з JSON.
5. Люди: список, фрагменти, ручний розбір, правило з виділення.
6. Правила парсера: дерево файлів.
7. Налаштування: шляхи / шрифт / кольори.

---

## 8. Наступні кроки

| Фаза | Зміст |
|------|--------|
| **3b** (опційно) | логіка people/quality у окремі controller-модулі |
| **4** | стилі/tags → `gui/widgets/` |
| **5** | тонкий entrypoint + перевірка PyInstaller hiddenimports для `tabs.*` |

---

*Фаза 3 завершена, якщо всі вкладки будуються через `tabs/*.build(app)` і smoke проходить.*
