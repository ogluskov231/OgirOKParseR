# Фаза 4 рефакторингу GUI — стилі та теги (`gui/widgets/`)

**Версія:** ОгрОК_UA v0.6.6 (Phase 4)  
**Мета:** винести **кольори, теги подій, завантаження UI-налаштувань і застосування шрифтів** з `parser_gui.App` у `gui/widgets/`, без зміни поведінки.

---

## 1. Що зроблено

| Було в `parser_gui` | Стало |
|---------------------|--------|
| `SPECIAL_CATEGORY_TAGS`, `_ui_tag_for_event_and_category` | `widgets/tags.py` |
| Дефолтні кольори highlight / event | `DEFAULT_HIGHLIGHT_COLORS`, `DEFAULT_EVENT_COLORS` |
| `_load_ui_settings` / `_save_ui_settings` | `text_styles.load_ui_settings` / `save_ui_settings` |
| `_apply_global_style` / `_apply_text_widget_style` | `text_styles.apply_*` |
| `_reconfigure_people_text_tags` | `text_styles.reconfigure_people_text_tags` |
| Дубльовані `tag_configure` у `people_tab` | `apply_tree_event_tags` + `reconfigure_people_text_tags` |
| `_reset_ui_colors` hardcoded hex | `DEFAULT_HIGHLIGHT_COLORS` |

`App` лишає тонкі обгортки (`self.ui_settings`, `self._font_bold`), щоб решта коду не ламалась.

---

## 2. Структура

```text
gui/widgets/
├── __init__.py          # реекспорт tags (без tkinter)
├── tags.py              # SPECIAL_*, ui_tag_for_event_and_category, default colors
└── text_styles.py       # load/save settings, apply fonts/tags (потребує tkinter)
```

Імпорт без GUI:

```python
from apps.parser_orders.src.gui.widgets.tags import ui_tag_for_event_and_category
```

З GUI:

```python
from apps.parser_orders.src.gui.widgets import text_styles as ui_styles
ui_styles.apply_global_style(root, settings)
```

---

## 3. `tags.py` — від А до Я

### `SPECIAL_CATEGORY_TAGS`
Мапа **label категорії з парсера** → ім’я Tk-тега (`SPECIAL_MED`, `SPECIAL_VACATION`, `SPECIAL_TRIP`).

### `ui_tag_for_event_and_category(event_type, category)`
1. Якщо category є в `SPECIAL_CATEGORY_TAGS` → той тег.
2. Інакше `arrival` → `ARRIVAL`, `departure` → `DEPARTURE`.
3. Інакше порожній tuple.

Використовується при вставці рядків у `frag_tree` / `docs_tree`.

### Кольори за замовчуванням
- **Highlight** (текст): `BLOCK_ACTIVE`, `MATCH_ACTIVE`, `CAT_MATCH`, `PIB_MATCH`, `FIND`
- **Event rows**: `EVT_ARRIVAL`, `EVT_DEPARTURE`, `EVT_SPECIAL_*`

Єдине місце правки «стандартної палітри».

---

## 4. `text_styles.py` — від А до Я

| Функція | Роль |
|---------|------|
| `default_ui_settings()` | font з TkTextFont + усі default colors |
| `load_ui_settings(path)` | JSON merge з defaults (валідація `#rgb`) |
| `save_ui_settings(path, settings)` | запис JSON |
| `apply_global_style(root, settings)` | ttk Style: Label/Button/Entry/Treeview |
| `apply_text_widget_style(widget, settings)` | font на Text/подібне |
| `reconfigure_people_text_tags(person_text, settings)` | HDR bold + highlight tags; повертає Font |
| `apply_tree_event_tags(tree, settings)` | ARRIVAL/DEPARTURE/SPECIAL_* на Treeview (або Text) |

---

## 5. Зміни в App

```python
def _load_ui_settings(self):
    return ui_styles.load_ui_settings(self.ui_settings_path)

def _apply_global_style(self):
    ui_styles.apply_global_style(self, self.ui_settings)

def _reconfigure_people_text_tags(self):
    bold = ui_styles.reconfigure_people_text_tags(self.person_text, self.ui_settings)
    if bold is not None:
        self._font_bold = bold
```

Аліас: `_ui_tag_for_event_and_category = ui_tag_for_event_and_category` (старі виклики в App).

---

## 6. Зміни в `people_tab.py`

- Замість ручних `tag_configure` → `reconfigure_people_text_tags` + `apply_tree_event_tags`.
- Виправлено артефакт Phase 3: `hasattr(self, ...)` → `hasattr(app, ...)`.

---

## 7. Що НЕ входило у Фазу 4

- Логіка people/quality (controllers)
- Перенесення `_pick_ui_color` UI (лишається в App; використовує settings + reconfigure)
- Зміна `ui_settings.json` schema

---

## 8. Smoke

1. Старт GUI — шрифти/кнопки виглядають як раніше.
2. Люди: кольори блоків, arrival/departure у таблиці фрагментів.
3. Налаштування → змінити колір / розмір шрифту → Застосувати → текст оновлюється.
4. Скинути кольори → defaults з `DEFAULT_HIGHLIGHT_COLORS`.

---

## 9. Наступне

| Фаза | Зміст |
|------|--------|
| **5** | Тонкий entrypoint, PyInstaller hiddenimports для `widgets`/`tabs`/`dialogs`/`services` |
| **3b** | Controllers для people/quality logic |

---

*Фаза 4 завершена, якщо стилі керуються з `gui/widgets/` і UI не змінив поведінку.*
