# Фаза 5 — тонкий entrypoint і PyInstaller freeze

**Версія:** ОгрОК_UA v0.6.7 (Phase 5)  
**Мета:** стабільна точка входу для запуску й збірки `.exe` після рефакторингу Phase 1–4 (`services`, `dialogs`, `tabs`, `widgets`).

---

## 1. Що зроблено

| Елемент | Зміна |
|---------|--------|
| **`run_gui.py`** (корінь проєкту) | Тонкий entry: `sys.path` → `from ...parser_gui import App` → `mainloop()` |
| **`OgrOK_UA.spec`** | Analysis script = `run_gui.py`; список **hiddenimports** для всіх пакетів рефакторингу + docx/openpyxl |
| **`scripts/build_exe_windows.bat`** | `pyinstaller --noconfirm OgrOK_UA.spec` (не сирий шлях до parser_gui) |
| **`RUN_GUI.bat`** | `py run_gui.py` |
| **`installer/OgrOK_UA.iss`** | `MyAppVersion` → **0.6.7** |
| **`BUILD_WINDOWS.md`** | Актуальні кроки збірки / перевірки freeze |
| **`parser_gui.py` `__main__`** | Залишено як fallback; рекомендовано `run_gui.py` |

---

## 2. Навіщо окремий entrypoint

Після Phase 1–4 логіка розкидана по підпакетах. Якщо PyInstaller аналізує лише глибокий `parser_gui.py`, інколи **не підтягує** модулі, імпортовані «збоку» (tabs/dialogs), особливо в `--noconsole` onedir.

`run_gui.py` на корені:

1. Гарантує `PROJECT_ROOT` у `sys.path`.
2. Явно імпортує `App`, який тягне tabs/dialogs/services/widgets.
3. Spec додатково перераховує **hiddenimports** — страховка для freeze.

---

## 3. Hiddenimports (короткий список)

```text
apps.parser_orders.src.services.pipeline_service
apps.parser_orders.src.gui.dialogs.*
apps.parser_orders.src.gui.tabs.*
apps.parser_orders.src.gui.widgets.*
apps.parser_orders.src.core.*
docx, openpyxl, openpyxl.cell._writer
```

Повний список — у `OgrOK_UA.spec` → `_hidden`.

Якщо після freeze з’являється `ModuleNotFoundError: No module named '…'`:

1. Додати рядок у `_hidden`.
2. Перезібрати `scripts\build_exe_windows.bat`.

---

## 4. Запуск

**Розробка:**

```bash
python run_gui.py
# або
RUN_GUI.bat
```

**CLI без змін:**

```bash
python run_parser_orders_cli.py --input input/documents --excel --json
python run_parser_orders_cli.py --from-json output/parsed/combined_v2.json --excel
```

**Fallback:**

```bash
python apps/parser_orders/src/gui/parser_gui.py
```

---

## 5. Збірка Windows

```text
scripts\build_exe_windows.bat
→ dist\OgrOK_UA\OgrOK_UA.exe
```

Inno Setup: `installer\OgrOK_UA.iss` → `OgrOK_UA_Setup_v0.6.7.exe`.

Datas у bundle: `templates`, `config`, `assets`, `input`.

У runtime `BASE_DIR` для frozen = тека exe (логіка вже в `parser_gui`).

---

## 6. Архітектура після Phase 1–5

```text
run_gui.py                 ← entry (Phase 5)
run_parser_orders_cli.py
OgrOK_UA.spec
apps/parser_orders/src/
  core/                    парсер, excel
  services/                pipeline (Phase 1)
  gui/
    parser_gui.py          App
    dialogs/               (Phase 2)
    tabs/                  (Phase 3)
    widgets/               (Phase 4)
```

---

## 7. Smoke після Phase 5

1. `python run_gui.py` — вікно відкривається.
2. Повний цикл DOCX → Excel / JSON.
3. Excel з JSON, ручний розбір, правило з виділення.
4. (На Windows) збірка spec → exe на чистій машині повторює п.1–3.

---

## 8. Підсумок рефакторингу 1–5

| Фаза | Результат |
|------|-----------|
| 1 | `pipeline_service` |
| 2 | `gui/dialogs` |
| 3 | `gui/tabs` |
| 4 | `gui/widgets` |
| 5 | `run_gui.py` + freeze hiddenimports |

*Фаза 5 завершує запланований каркас рефакторингу GUI/дистрибуції.*
