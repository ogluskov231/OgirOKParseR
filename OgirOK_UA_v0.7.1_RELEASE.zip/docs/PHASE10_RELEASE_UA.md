# Phase 10+ (покращена) — релізний каркас

**Версія:** 0.7.1

## Проблема 0.7.0

Phase 10 була «тонкою»: CHANGELOG + короткий ARCHITECTURE, але:

- версія дублювалась вручну (ISS / README / BUILD / spec розходились);
- `smoke_check` лише ганяв unittest;
- не було єдиного чеклисту «коли можна віддавати».

## Що змінено в 0.7.1

1. **`VERSION`** — single source of truth  
2. **`apps.parser_orders.__version__`** читає `VERSION`  
3. **`scripts/smoke_check.py`** — 5 блоків перевірок (структура, version sync, AST, config/imports, tests)  
4. **`docs/RELEASE_CHECKLIST_UA.md`** — A–F до релізу  
5. Узгоджені `BUILD_WINDOWS.md`, spec, ISS, README, CHANGELOG  

## Як релізити нову версію

```text
1. Записати номер у VERSION
2. Оновити ISS MyAppVersion + CHANGELOG секцію
3. python scripts/smoke_check.py   # exit 0
4. Функціональний smoke (GUI/CLI)
5. (Windows) build_exe + Inno Setup
6. Zip сирців без .venv/output
```

Деталі: `docs/RELEASE_CHECKLIST_UA.md`.
