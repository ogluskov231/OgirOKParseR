# Чеклист релізу ОгрОК_UA (Phase 10+)

**Джерело правди для версії:** файл `VERSION` у корені проєкту.

Перед кожним публічним релізом виконай пункти по порядку.

---

## A. Версія (обов’язково)

1. Оновити **`VERSION`** (наприклад `0.7.1`).
2. `installer/OgrOK_UA.iss` → `#define MyAppVersion` = те саме.
3. `CHANGELOG.md` → секція `## 0.7.1` зверху.
4. `README.md` — згадка версії.
5. `BUILD_WINDOWS.md` — версія setup/exe.
6. `OgrOK_UA.spec` — коментар з версією.
7. Перевірка: `python scripts/smoke_check.py` → блок **Version sync OK**.

`apps.parser_orders.__version__` читається з `VERSION` автоматично.

---

## B. Автоматичний smoke (обов’язково)

```bash
python scripts/smoke_check.py
```

Має пройти:

| Крок | Що перевіряє |
|------|----------------|
| 1 | Наявність ключових файлів/модулів |
| 2 | Синхрон версії ISS / package / README / CHANGELOG / BUILD / spec |
| 3 | Синтаксис AST усього `src/` + entrypoints |
| 4 | `mapping.json`, шаблон Excel, критичні імпорти |
| 5 | `unittest discover tests` |

Код виходу: `0` = можна пакувати; `1` = тести/імпорти; `2` = структура/версія.

---

## C. Функціональний smoke (на машині з GUI)

1. `python run_gui.py` або `RUN_GUI.bat`
2. DOCX у `input/documents/` → **Обробити**
3. Є `output/parsed/combined_v2.json` і `output/exports/excel/N_filled_*.xlsx`
4. Вкладка **Люди** — список, фрагменти, підсвітка
5. **Ручний розбір полів** → Save → JSON оновлено
6. **Excel з JSON** / **З combined_v2.json**
7. CLI:
   - `python run_parser_orders_cli.py --input input/documents --excel --json`
   - `python run_parser_orders_cli.py --from-json output/parsed/combined_v2.json --excel`

---

## D. Windows-збірка

1. `scripts\build_exe_windows.bat` → `dist\OgrOK_UA\OgrOK_UA.exe`
2. Запуск exe **без** системного Python
3. Повторити пункти C.2–C.6 з exe
4. Inno Setup: `installer\OgrOK_UA.iss` → `installer_output\OgrOK_UA_Setup_v{VERSION}.exe`
5. Встановлення на чисту машину / пісочницю → uninstall

---

## E. Пакування сирців (zip)

Не включати:

- `.venv`, `build`, `dist`, `__pycache__`, `.pytest_cache`
- `output/**` (результати користувача)
- реальні накази в `input/documents` (лише `.keep`)

Ім’я архіву: `OgirOK_UA_v{VERSION}_….zip`

У архіві мають бути: `VERSION`, `CHANGELOG.md`, `docs/`, `run_gui.py`, `OgrOK_UA.spec`.

---

## F. Критерій «можна віддавати»

- [ ] `smoke_check.py` → exit 0  
- [ ] GUI/CLI цикл DOCX→Excel і JSON→Excel  
- [ ] (якщо реліз Windows) exe + setup з тією ж версією  
- [ ] CHANGELOG описує зміни цього тегу  

---

*Оновлено в рамках покращеної Phase 10 (v0.7.1).*
