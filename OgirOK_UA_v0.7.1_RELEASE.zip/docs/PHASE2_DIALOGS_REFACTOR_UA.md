# Фаза 2 рефакторингу GUI — винесення діалогів

**Версія:** ОгрОК_UA v0.6.4 (Phase 2)  
**Мета:** винести UI діалогів «Правило з виділення» і «Ручний розбір полів» з монолітного `parser_gui.py` у `gui/dialogs/`, **без зміни поведінки** для користувача.

---

## 1. Що зроблено

| Було | Стало |
|------|--------|
| `_open_rule_dialog` ~80 рядків у `App` | `gui/dialogs/rule_from_selection.py` → `open_rule_from_selection_dialog` |
| `_manual_field_parse` ~300 рядків UI+логіка в `App` | `gui/dialogs/manual_fields.py` → `open_manual_fields_dialog` + helpers |
| `_find_record_for_mention` у App | `find_record_for_mention` у `manual_fields.py` (App делегує) |
| load/save combined для manual | `load_combined_json` / `save_combined_json` у `manual_fields.py` |

**Залишилось в App (тонкі обгортки):**
- `_add_rule_from_selection` — зчитує виділення / default_event, викликає діалог
- `_open_rule_dialog` — передає `cat_engine` + `on_persist=_persist_category_rule`
- `_persist_category_rule` — як і раніше пише `user_category_rules.json` і оновлює view
- `_manual_field_parse` — збирає pib/meta/combined, викликає діалог, `on_after_save` оновлює дерево людей

---

## 2. Структура

```text
apps/parser_orders/src/gui/
├── parser_gui.py
└── dialogs/                          # ★ Phase 2
    ├── __init__.py
    ├── rule_from_selection.py
    └── manual_fields.py
```

---

## 3. `rule_from_selection.py` — від А до Я

### Функція `open_rule_from_selection_dialog(...)`

| Аргумент | Роль |
|----------|------|
| `parent` | Tk root (transient + grab) |
| `phrase` | Текст з виділення |
| `default_event` | arrival / departure |
| `cat_engine` | labels для Combobox |
| `make_regex_from_phrase` | генерація regex (з core) |
| `on_persist` | callback `(event_type, label, regex, priority_high)` |

**Кроки UI (як раніше):**
1. Readonly поле «Виділена фраза»
2. Radio arrival/departure
3. Combobox категорії (оновлюється при зміні event)
4. Regex + checkbox пріоритету
5. Зберегти → валідація → `on_persist` → destroy

**Чому callback, а не запис JSON у діалозі:**  
збереження правил чіпає `user_category_rules_path`, `_ensure_category_engine`, `_render_person_into_ui` — це стан App; діалог лишається «тупим» UI.

---

## 4. `manual_fields.py` — від А до Я

### Helpers

| Функція | Роль |
|---------|------|
| `find_record_for_mention(person, doc, block_id)` | Пошук record за doc+block_id |
| `load_combined_json(path)` | Читання combined |
| `save_combined_json(data, path)` | Запис combined |
| `apply_manual_payload(...)` | Мутація records/mentions/ranks/pib з payload форми |

### `open_manual_fields_dialog(...)`

| Аргумент | Роль |
|----------|------|
| `pib`, `selected_text`, `meta` | Контекст фрагмента |
| `combined`, `person_obj`, `rec` | Дані для редагування (вже знайдені App) |
| `doc`, `block_id`, `combined_path` | Ідентифікація + шлях збереження |
| `get_selected_text` | Для кнопки «Вставити виділене» |
| `on_after_save(new_pib)` | Після успішного save — refresh people tree |

**Поля форми:** ПІБ, звання, категорія звання, event, посада, from/to unit, дати, джерело/причина, категорія, номер наказу, примітка — без змін набору.

**Збереження:** `apply_manual_payload` → `save_combined_json` → `on_after_save` → messagebox.

---

## 5. Зміни в `parser_gui.py`

Імпорти:
```python
from apps.parser_orders.src.gui.dialogs.rule_from_selection import open_rule_from_selection_dialog
from apps.parser_orders.src.gui.dialogs.manual_fields import (
    open_manual_fields_dialog,
    find_record_for_mention,
    load_combined_json,
)
```

Кнопки / context menu **ті самі** команди: `_add_rule_from_selection`, `_manual_field_parse`.

---

## 6. Що НЕ змінювалось

- Phase 1 `services/pipeline_service.py`
- Парсер, excel_autofill, mapping
- `_persist_category_rule` (логіка id/rules JSON)
- Назви кнопок і тексти попереджень (майже ідентичні; messagebox інколи з `parent=`)

---

## 7. Smoke-перевірка

1. Запуск GUI.
2. Обробити DOCX → вкладка Люди.
3. Виділити фразу → **Правило з виділення** → зберегти правило → файл `user_category_rules.json` оновлюється.
4. **Ручний розбір полів** → змінити звання/дату → Зберегти → combined_v2.json і UI оновлені.
5. Context menu (ПКМ) на тексті — обидва пункти працюють.

---

## 8. Наступна фаза (3)

Винесення вкладок у `gui/tabs/` (input, run, results, people, quality, settings) — окремими модулями `build_*(app, parent)`.

---

*Фаза 2 завершена, якщо обидва діалоги відкриваються і зберігають дані як у v0.6.3.*
