# Архітектура ОгрОК_UA (v0.7.1)

## Потік даних

```text
DOCX → core/docx_parser + CategoryEngine
     → combined_v2.json (people[].records / mentions)
     → core/excel_autofill + config/autofill/mapping.json
     → N_filled_*.xlsx
```

JSON-first: Excel без повторного парсингу (`autofill_from_json_file`, GUI, CLI `--from-json`).

## Пакети

| Пакет | Роль | Фаза |
|-------|------|------|
| `core/` | Парсер, Excel, категорії, schema | — |
| `services/pipeline_service` | DOCX→JSON→Excel без UI | 1 |
| `services/app_paths` | BASE/config/output (source + frozen) | 8 |
| `gui/dialogs/` | Правило з виділення, ручний розбір | 2 |
| `gui/tabs/` | Побудова вкладок Notebook | 3 |
| `gui/widgets/` | Теги подій, ui_settings, шрифти | 4 |
| `gui/controllers/` | People data + quality rules (без Tk) | 6–7 |
| `gui/parser_gui.py` | App: стан, обробники | — |
| `run_gui.py` | Entrypoint | 5 |

## Версія та реліз (Phase 10+)

| Файл | Призначення |
|------|-------------|
| `VERSION` | Єдине джерело номера релізу |
| `apps/parser_orders/__init__.py` | `__version__` з `VERSION` |
| `scripts/smoke_check.py` | Структура, version sync, AST, імпорти, unittest |
| `docs/RELEASE_CHECKLIST_UA.md` | Людський чеклист перед віддачею |
| `CHANGELOG.md` | Історія змін |
| `OgrOK_UA.spec` + ISS | Freeze / інсталятор |

## Точки входу

- GUI: `python run_gui.py`
- CLI: `run_parser_orders_cli.py`
- Smoke: `python scripts/smoke_check.py`
- Windows: `scripts/build_exe_windows.bat`

## Конфіг

- `config/autofill/mapping.json` — колонки Excel
- `config/categories/*`, `config/learning/*`
- `config/ui_settings.json`
- `templates/N_fixed.xlsx`
