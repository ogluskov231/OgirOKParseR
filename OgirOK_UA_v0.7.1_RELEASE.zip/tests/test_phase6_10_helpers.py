"""Unit tests for Phases 6–9 helpers (no Tk required)."""

from __future__ import annotations

import json
import os
import tempfile
import unittest

from apps.parser_orders.src.gui.controllers.people_data import (
    parse_dt_key,
    build_global_category_index,
    collect_person_export_payload,
    person_txt_lines,
)
from apps.parser_orders.src.gui.controllers.quality_rules import (
    QUALITY_FILE_MAP,
    validate_json_file,
    list_quality_statuses,
    import_quality_file,
    export_quality_files,
)
from apps.parser_orders.src.gui.widgets.tags import ui_tag_for_event_and_category
from apps.parser_orders.src.services.pipeline_service import flatten_records
from apps.parser_orders.src.services.app_paths import get_app_paths, resolve_base_dir


class TestPeopleData(unittest.TestCase):
    def test_parse_dt_key_order(self):
        a = parse_dt_key("01.02.2024")
        b = parse_dt_key("15.03.2024")
        self.assertLess(a, b)
        self.assertEqual(parse_dt_key("")[0], 1)

    def test_category_index(self):
        people = [
            {
                "pib": "ТЕСТ ІВАН",
                "mentions": [
                    {"category": "КатА", "event_type": "arrival"},
                    {"category": "КатА", "event_type": "departure"},
                ],
                "records": [],
            }
        ]
        idx = build_global_category_index(people)
        self.assertIn("КатА", idx)
        self.assertEqual(idx["КатА"]["count"], 2)
        self.assertEqual(idx["КатА"]["arrivals"], 1)

    def test_export_payload(self):
        person = {"ranks": ["солдат"], "records": [{"pib": "A"}], "mentions": []}
        payload = collect_person_export_payload("A B C", person)
        self.assertEqual(payload["pib"], "A B C")
        self.assertEqual(len(payload["records"]), 1)
        lines = person_txt_lines("A B C", person)
        self.assertTrue(any("ПІБ" in x for x in lines))


class TestQualityRules(unittest.TestCase):
    def test_map_has_mapping(self):
        self.assertIn("mapping.json", QUALITY_FILE_MAP)

    def test_validate_missing(self):
        ok, msg = validate_json_file("/nonexistent/path.json")
        self.assertFalse(ok)
        self.assertEqual(msg, "ВІДСУТНІЙ")

    def test_import_export_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = os.path.join(tmp, "config")
            os.makedirs(os.path.join(cfg, "learning"), exist_ok=True)
            src = os.path.join(tmp, "units.json")
            with open(src, "w", encoding="utf-8") as f:
                json.dump({"a": "b"}, f)
            ok, msg = import_quality_file(src, cfg)
            self.assertTrue(ok, msg)
            self.assertTrue(os.path.isfile(os.path.join(cfg, "learning", "units.json")))
            out = os.path.join(tmp, "out")
            os.makedirs(out)
            n = export_quality_files(cfg, out)
            self.assertGreaterEqual(n, 1)
            rows = list_quality_statuses(cfg)
            names = [r[0] for r in rows]
            self.assertIn("units.json", names)


class TestTagsAndPipeline(unittest.TestCase):
    def test_tags(self):
        self.assertEqual(ui_tag_for_event_and_category("arrival", None), ("ARRIVAL",))
        self.assertEqual(ui_tag_for_event_and_category("x", "У відрядження"), ("SPECIAL_TRIP",))

    def test_flatten(self):
        data = {
            "people": [
                {"pib": "А Б В", "records": [{"event_type": "arrival"}]},
            ]
        }
        recs = flatten_records(data)
        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0]["pib"], "А Б В")


class TestAppPaths(unittest.TestCase):
    def test_resolve(self):
        root = resolve_base_dir("/tmp/ogirok_fake_root")
        self.assertTrue(root.endswith("ogirok_fake_root") or "ogirok_fake_root" in root)
        paths = get_app_paths("/tmp/ogirok_fake_root")
        self.assertTrue(paths.combined_json.endswith("combined_v2.json"))
        self.assertIn("templates", paths.templates)


if __name__ == "__main__":
    unittest.main()
